import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from PIL import Image
import cv2
import pandas as pd
import os

def train_features_extractor(path, train_lib, trans, batch_size, model, device):
    for i, image in enumerate(train_lib["images"]):
        cols = []
        rows=[]

        for patch in train_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            cols.append(int(col))
            rows.append(int(row))
        col_last = sorted(np.array(cols))[-1]
        row_last = sorted(np.array(rows))[-1]
        image = np.zeros((row_last+1, col_last+1, 1000))
    
        patches_batch = []  # 摆渡车
        patches_pos = []  # 补丁位置
        img_features =[]
        for patch in train_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            patches_pos.append([int(col), int(row)])
    
        for j, patch in enumerate(train_lib["images"][i]):

            patch = cv2.imread(patch)
            patch = cv2.resize(patch, (384, 384))
            patch = cv2.cvtColor(patch, cv2.COLOR_BGR2RGB)
        
            patch = trans(patch).unsqueeze(0)
            patches_batch.append(patch)
        
            if ((j+1) % batch_size == 0) or ((j+1) == len(train_lib["images"][i])):
                patches_batch = torch.cat(patches_batch, 0).to(device)
                _, features = model(patches_batch)
                #features = features.softmax(dim = -1)
                features = features.cpu().tolist()
                for k in range(len(features)):
                    img_features.append(features[k])
                patches_batch = []  # 清空摆渡车
    
        for index in range(len(patches_pos)):
            image[patches_pos[index][1], patches_pos[index][0]] = torch.Tensor(img_features[index])
    
        #train_lib["images"][i] = image

        torch.save(image, "store_4/{}.db".format(train_lib["pathid"][i]))

    images = []
    for i, pathid in enumerate(train_lib["pathid"]):
        images.append(os.path.join(path, "store_4", pathid+".db"))
    c = {"pathid": train_lib["pathid"], "images": images, "labels": train_lib["labels"]}
    df = pd.DataFrame(c)
    df.to_csv("files/store_4_train.csv", index=False, encoding="utf_8_sig")
    torch.save(c, "files/store_4_train.db")
    return "store_4_train.db"

def valid_features_extractor(path, valid_lib, trans, batch_size, model, device):
    for i, image in enumerate(valid_lib["images"]):
        cols = []
        rows = []

        for patch in valid_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            cols.append(int(col))
            rows.append(int(row))
        col_last = sorted(np.array(cols))[-1]
        row_last = sorted(np.array(rows))[-1]
        image = np.zeros((int(row_last)+1, int(col_last)+1, 1000))
    
        patches_batch = []  # 摆渡车
        patches_pos = []  # 补丁位置
        img_features =[]
        for patch in valid_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            patches_pos.append([int(col), int(row)])
    
        for j, patch in enumerate(valid_lib["images"][i]):

            patch = cv2.imread(patch)
            patch = cv2.resize(patch, (384, 384))
            patch = cv2.cvtColor(patch, cv2.COLOR_BGR2RGB)
        
            patch = trans(patch).unsqueeze(0)
            patches_batch.append(patch)
        
            if ((j+1) % batch_size == 0) or ((j+1) == len(valid_lib["images"][i])):
                patches_batch = torch.cat(patches_batch, 0).to(device)
                _, features = model(patches_batch)
                #features = features.softmax(dim = -1)
                features = features.cpu().tolist()
                for k in range(len(features)):
                    img_features.append(features[k])
                patches_batch = []  # 清空摆渡车
    
        for index in range(len(patches_pos)):
            image[patches_pos[index][1], patches_pos[index][0]] = torch.Tensor(img_features[index])
    
        #train_lib["images"][i] = image
    
        torch.save(image, "store_4/{}.db".format(valid_lib["pathid"][i]))
    
    images = []
    for i, pathid in enumerate(valid_lib["pathid"]):
        images.append(os.path.join(path, "store_4", pathid+".db"))
    c = {"pathid": valid_lib["pathid"], "images": images, "labels": valid_lib["labels"]}
    df = pd.DataFrame(c)
    df.to_csv("files/store_4_valid.csv", index=False, encoding="utf_8_sig")
    torch.save(c, "files/store_4_valid.db")
    return "store_4_valid.db"

def train_features_extractor_surv(path, train_lib, trans, batch_size, model, device):
    for i, image in enumerate(train_lib["images"]):
        cols = []
        rows=[]

        for patch in train_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            cols.append(int(col))
            rows.append(int(row))
        col_last = sorted(np.array(cols))[-1]
        row_last = sorted(np.array(rows))[-1]
        image = np.zeros((row_last+1, col_last+1, 1000))
    
        patches_batch = []  # 摆渡车
        patches_pos = []  # 补丁位置
        img_features =[]
        for patch in train_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            patches_pos.append([int(col), int(row)])
    
        for j, patch in enumerate(train_lib["images"][i]):

            patch = cv2.imread(patch)
            patch = cv2.resize(patch, (384, 384))
            patch = cv2.cvtColor(patch, cv2.COLOR_BGR2RGB)
        
            patch = trans(patch).unsqueeze(0)
            patches_batch.append(patch)
        
            if ((j+1) % batch_size == 0) or ((j+1) == len(train_lib["images"][i])):
                patches_batch = torch.cat(patches_batch, 0).to(device)
                _, features = model(patches_batch)
                #features = features.softmax(dim = -1)
                features = features.cpu().tolist()
                for k in range(len(features)):
                    img_features.append(features[k])
                patches_batch = []  # 清空摆渡车
    
        for index in range(len(patches_pos)):
            image[patches_pos[index][1], patches_pos[index][0]] = torch.Tensor(img_features[index])
    
        #train_lib["images"][i] = image

        torch.save(image, "store_4/{}.db".format(train_lib["pathid"][i]))

    images = []
    for i, pathid in enumerate(train_lib["pathid"]):
        images.append(os.path.join(path, "store_4", pathid+".db"))
    c = {"pathid": train_lib["pathid"], "images": images, "labels": train_lib["labels"], "time": train_lib["time"], "event": train_lib["event"]}
    df = pd.DataFrame(c)
    df.to_csv("files/store_4_train_surv.csv", index=False, encoding="utf_8_sig")
    torch.save(c, "files/store_4_train_surv.db")
    return "store_4_train_surv.db"

def valid_features_extractor_surv(path, valid_lib, trans, batch_size, model, device):
    for i, image in enumerate(valid_lib["images"]):
        cols = []
        rows = []

        for patch in valid_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            cols.append(int(col))
            rows.append(int(row))
        col_last = sorted(np.array(cols))[-1]
        row_last = sorted(np.array(rows))[-1]
        image = np.zeros((int(row_last)+1, int(col_last)+1, 1000))
    
        patches_batch = []  # 摆渡车
        patches_pos = []  # 补丁位置
        img_features =[]
        for patch in valid_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            patches_pos.append([int(col), int(row)])
    
        for j, patch in enumerate(valid_lib["images"][i]):

            patch = cv2.imread(patch)
            patch = cv2.resize(patch, (384, 384))
            patch = cv2.cvtColor(patch, cv2.COLOR_BGR2RGB)
        
            patch = trans(patch).unsqueeze(0)
            patches_batch.append(patch)
        
            if ((j+1) % batch_size == 0) or ((j+1) == len(valid_lib["images"][i])):
                patches_batch = torch.cat(patches_batch, 0).to(device)
                _, features = model(patches_batch)
                #features = features.softmax(dim = -1)
                features = features.cpu().tolist()
                for k in range(len(features)):
                    img_features.append(features[k])
                patches_batch = []  # 清空摆渡车
    
        for index in range(len(patches_pos)):
            image[patches_pos[index][1], patches_pos[index][0]] = torch.Tensor(img_features[index])
    
        #train_lib["images"][i] = image
    
        torch.save(image, "store_4/{}.db".format(valid_lib["pathid"][i]))
    
    images = []
    for i, pathid in enumerate(valid_lib["pathid"]):
        images.append(os.path.join(path, "store_4", pathid+".db"))
    c = {"pathid": valid_lib["pathid"], "images": images, "labels": valid_lib["labels"], "time": valid_lib["time"], "event": valid_lib["event"]}
    df = pd.DataFrame(c)
    df.to_csv("files/store_4_valid_surv.csv", index=False, encoding="utf_8_sig")
    torch.save(c, "files/store_4_valid_surv.db")
    return "store_4_valid_surv.db"

def train_features_extractor_gpvit(path, train_lib, transform, batch_size, model, device):
    #model = model.to(device)
    #model = nn.DataParallel(model)
    model.eval()

    for i, image in enumerate(train_lib["images"]):
        cols = []
        rows=[]

        for patch in train_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            cols.append(int(col))
            rows.append(int(row))
        col_last = sorted(np.array(cols))[-1]
        row_last = sorted(np.array(rows))[-1]
        image = torch.zeros((row_last+1) * 12, (col_last+1) * 12, 768)
    
        patches_batch = []  # 摆渡车
        patches_pos = []  # 补丁位置
        img_features =[]
        for patch in train_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            patches_pos.append([int(col), int(row)])
    
        for j, patch in enumerate(train_lib["images"][i]):
            torch.cuda.empty_cache() 
            #patch = cv2.imread(patch)
            #patch = cv2.resize(patch, (384, 384))
            #patch = cv2.cvtColor(patch, cv2.COLOR_BGR2RGB)
            patch = Image.open(patch)

            patch = transform(patch).unsqueeze(0) 
            patches_batch.append(patch)
        
            if ((j+1) % batch_size == 0) or ((j+1) == len(train_lib["images"][i])):
                torch.cuda.empty_cache()  
                patches_batch = torch.cat(patches_batch, 0).to(device)
                _, features = model(patches_batch)
                #features = features.softmax(dim = -1)
                features = features.cpu().tolist()
                for k in range(len(features)):
                    img_features.append(features[k])
                patches_batch = []  # 清空摆渡车
    
        for index in range(len(patches_pos)):
            batch_range = torch.arange(patches_pos[index][1], patches_pos[index][1] + 12)[:, None]
            indices = torch.arange(patches_pos[index][0], patches_pos[index][0] + 12)
            image[batch_range, indices] = torch.Tensor(img_features[index]).reshape(12, 12, 768)
    
        #train_lib["images"][i] = image

        torch.save(image, "store_5/{}.db".format(train_lib["pathid"][i]))

    images = []
    for i, pathid in enumerate(train_lib["pathid"]):
        images.append(os.path.join(path, "store_5", pathid+".db"))
    c = {"pathid": train_lib["pathid"], "images": images, "labels": train_lib["labels"]}
    df = pd.DataFrame(c)
    df.to_csv("files/store_5_train.csv", index=False, encoding="utf_8_sig")
    torch.save(c, "files/store_5_train.db")
    return "store_5_train.db"

def train_features_extractor_gpvit2(path, train_lib, transform, batch_size, model, device):
    #model = model.to(device)
    #model = nn.DataParallel(model)
    model.eval()

    for i, image in enumerate(train_lib["images"]):
        cols = []
        rows=[]

        for patch in train_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            cols.append(int(col))
            rows.append(int(row))
        col_last = sorted(np.array(cols))[-1]
        row_last = sorted(np.array(rows))[-1]
        image = torch.zeros((row_last+1), (col_last+1), 768)
    
        patches_batch = []  # 摆渡车
        patches_pos = []  # 补丁位置
        img_features =[]
        for patch in train_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            patches_pos.append([int(col), int(row)])
    
        for j, patch in enumerate(train_lib["images"][i]):
            torch.cuda.empty_cache() 
            #patch = cv2.imread(patch)
            #patch = cv2.resize(patch, (384, 384))
            #patch = cv2.cvtColor(patch, cv2.COLOR_BGR2RGB)
            patch = Image.open(patch)

            patch = transform(patch).unsqueeze(0) 
            patches_batch.append(patch)
        
            if ((j+1) % batch_size == 0) or ((j+1) == len(train_lib["images"][i])):
                torch.cuda.empty_cache()  
                patches_batch = torch.cat(patches_batch, 0).to(device)
                _, features = model(patches_batch)
                #features = features.softmax(dim = -1)
                features = features.cpu().tolist()
                for k in range(len(features)):
                    img_features.append(features[k])
                patches_batch = []  # 清空摆渡车
    
        for index in range(len(patches_pos)):
            batch_range = torch.arange(patches_pos[index][1], patches_pos[index][1] + 1)[:, None]
            indices = torch.arange(patches_pos[index][0], patches_pos[index][0] + 1)
            image[batch_range, indices] = torch.Tensor(img_features[index]).reshape(1, 1, 768)
    
        #train_lib["images"][i] = image

        torch.save(image, "store_5_96/{}.db".format(train_lib["pathid"][i]))

    images = []
    for i, pathid in enumerate(train_lib["pathid"]):
        images.append(os.path.join(path, "store_5_96", pathid+".db"))
    c = {"pathid": train_lib["pathid"], "images": images, "labels": train_lib["labels"]}
    df = pd.DataFrame(c)
    df.to_csv("files_label/store_5_96_train.csv", index=False, encoding="utf_8_sig")
    torch.save(c, "files_label/store_5_96_train.db")
    return "store_5_96_train.db"

def valid_features_extractor_gpvit2(path, train_lib, transform, batch_size, model, device):
    #model = model.to(device)
    #model = nn.DataParallel(model)
    model.eval()

    for i, image in enumerate(train_lib["images"]):
        cols = []
        rows=[]

        for patch in train_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            cols.append(int(col))
            rows.append(int(row))
        col_last = sorted(np.array(cols))[-1]
        row_last = sorted(np.array(rows))[-1]
        image = torch.zeros((row_last+1), (col_last+1), 768)
    
        patches_batch = []  # 摆渡车
        patches_pos = []  # 补丁位置
        img_features =[]
        for patch in train_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            patches_pos.append([int(col), int(row)])
    
        for j, patch in enumerate(train_lib["images"][i]):
            torch.cuda.empty_cache() 
            #patch = cv2.imread(patch)
            #patch = cv2.resize(patch, (384, 384))
            #patch = cv2.cvtColor(patch, cv2.COLOR_BGR2RGB)
            patch = Image.open(patch)

            patch = transform(patch).unsqueeze(0) 
            patches_batch.append(patch)
        
            if ((j+1) % batch_size == 0) or ((j+1) == len(train_lib["images"][i])):
                torch.cuda.empty_cache()  
                patches_batch = torch.cat(patches_batch, 0).to(device)
                _, features = model(patches_batch)
                #features = features.softmax(dim = -1)
                features = features.cpu().tolist()
                for k in range(len(features)):
                    img_features.append(features[k])
                patches_batch = []  # 清空摆渡车
    
        for index in range(len(patches_pos)):
            batch_range = torch.arange(patches_pos[index][1], patches_pos[index][1] + 1)[:, None]
            indices = torch.arange(patches_pos[index][0], patches_pos[index][0] + 1)
            image[batch_range, indices] = torch.Tensor(img_features[index]).reshape(1, 1, 768)
    
        #train_lib["images"][i] = image

        torch.save(image, "store_5_96/{}.db".format(train_lib["pathid"][i]))

    images = []
    for i, pathid in enumerate(train_lib["pathid"]):
        images.append(os.path.join(path, "store_5_96", pathid+".db"))
    c = {"pathid": train_lib["pathid"], "images": images, "labels": train_lib["labels"]}
    df = pd.DataFrame(c)
    df.to_csv("files_label/store_5_96_valid.csv", index=False, encoding="utf_8_sig")
    torch.save(c, "files_label/store_5_96_valid.db")
    return "store_5_96_valid.db"


def train_features_extractor_gpvit_layer2(path, train_lib, transform, batch_size, model, device, subsample = -1):
    #model = model.to(device)
    #model = nn.DataParallel(model)
    train_lib = torch.load(train_lib)

    model.eval()

    for i, image in enumerate(train_lib["images"]):
        
        image_batch = []  # 摆渡车
        torch.cuda.empty_cache() 
        image = torch.load(image)
        image = np.array(image)

        image = transform(image).unsqueeze(0).to(device)
        image = F.interpolate(image, size =(subsample, subsample))

        image_batch.append(image)
        
        timer = 0

        if ((i+1) % batch_size == 0) or ((i+1) == len(train_lib["images"])):

            torch.cuda.empty_cache()  
            image_batch = torch.cat(image_batch, 0)
            features = model(image_batch)
            features = features.cpu().tolist()
    
            for k in range(len(features)):
                #images.append(features[k])
                
                torch.save(features[k], "store_6/{}.db".format(train_lib["pathid"][timer * batch_size + k]))
                
            timer += 1
            image_batch = []  # 清空摆渡车

    images = []
    for i, pathid in enumerate(train_lib["pathid"]):
        images.append(os.path.join(path, "store_6", pathid+".db"))
    c = {"pathid": train_lib["pathid"], "images": images, "labels": train_lib["labels"]}
    df = pd.DataFrame(c)
    df.to_csv("files/store_6_train.csv", index=False, encoding="utf_8_sig")
    torch.save(c, "files/store_6_train.db")
    return "store_6_train.db"

def valid_features_extractor_gpvit(path, valid_lib, transform, batch_size, model, device):
    model = model.to(device)
    model = nn.DataParallel(model)
    model.eval()

    for i, image in enumerate(valid_lib["images"]):
        cols = []
        rows=[]

        for patch in valid_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            cols.append(int(col))
            rows.append(int(row))
        col_last = sorted(np.array(cols))[-1]
        row_last = sorted(np.array(rows))[-1]
        image = torch.zeros((row_last+1) * 12, (col_last+1) * 12, 768)
    
        patches_batch = []  # 摆渡车
        patches_pos = []  # 补丁位置
        img_features =[]
        for patch in valid_lib["images"][i]:
            col, row = patch.split("/")[-1].split(".")[0].split("_")
            patches_pos.append([int(col), int(row)])
    
        for j, patch in enumerate(valid_lib["images"][i]):

            patch = cv2.imread(patch)
            patch = cv2.resize(patch, (384, 384))
            patch = cv2.cvtColor(patch, cv2.COLOR_BGR2RGB)
        
            patch = transform(patch).unsqueeze(0) 
            patches_batch.append(patch)
        
            if ((j+1) % batch_size == 0) or ((j+1) == len(valid_lib["images"][i])):
                patches_batch = torch.cat(patches_batch, 0).to(device)
                _, _, features = model(patches_batch)
                #features = features.softmax(dim = -1)
                features = features.cpu().tolist()
                for k in range(len(features)):
                    img_features.append(features[k])
                patches_batch = []  # 清空摆渡车
    
        for index in range(len(patches_pos)):
            batch_range = torch.arange(patches_pos[index][1], patches_pos[index][1] + 12)[:, None]
            indices = torch.arange(patches_pos[index][0], patches_pos[index][0] + 12)
            image[batch_range, indices] = torch.Tensor(img_features[index]).reshape(12, 12, 768)
    
        #train_lib["images"][i] = image

        torch.save(image, "store_5/{}.db".format(valid_lib["pathid"][i]))

    images = []
    for i, pathid in enumerate(valid_lib["pathid"]):
        images.append(os.path.join(path, "store_5", pathid+".db"))
    c = {"pathid": valid_lib["pathid"], "images": images, "labels": valid_lib["labels"]}
    df = pd.DataFrame(c)
    df.to_csv("files/store_5_valid.csv", index=False, encoding="utf_8_sig")
    torch.save(c, "files/store_5_valid.db")
    return "store_5_valid.db"