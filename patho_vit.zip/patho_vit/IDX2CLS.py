IDX2CLS = {0: "Silva Type A",
           1: "Silva Type B",
           2: "Silva Type C"}