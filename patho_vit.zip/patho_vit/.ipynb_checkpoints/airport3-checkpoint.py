import torch
import torch.nn.functional as F
import math
from collections import OrderedDict
from .vit import vit_base_patch16_384 as vit
import torch.nn as nn
import torchtuples as tt

class layer2dataset(torch.utils.data.Dataset):
    def __init__(self, libraryfile = "", transform=None, subsample=-1):
        file = torch.load(libraryfile)
        # 原始表格一个病人一行，一共三列，第一列为病理号，
        # 每行的第二列为一个列表，其中是新图片的路径，
        # 第三列为标签值
        self.pathid = file["pathid"]
        self.images = file["images"]
        self.labels = file["labels"]
        
        self.subsample = subsample
        self.transform = transform
    
    def __getitem__(self, index):
        image = torch.load(self.images[index])
        
        if self.subsample != -1 and self.transform is not None:
            
            image = self.transform(image)
            image = image.unsqueeze(0)
            image = F.interpolate(image, size =(self.subsample, self.subsample))
            image = image.squeeze(0)
            image = image.to(torch.float32)
        
        label = self.labels[index]
        return image, label
    
    def __len__(self):
        return len(self.pathid)
    
class layer2dataset_surv(torch.utils.data.Dataset):
    def __init__(self, libraryfile = "", transform=None, subsample=-1, target = None):
        file = torch.load(libraryfile)
        # 原始表格一个病人一行，一共三列，第一列为病理号，
        # 每行的第二列为一个列表，其中是新图片的路径，
        # 第三列为标签值
        self.pathid = file["pathid"]
        self.images = file["images"]
        self.labels = file["labels"]
        
        self.subsample = subsample
        self.transform = transform

        self.time, self.event = tt.tuplefy(*target).to_tensor()
    
    def __getitem__(self, index):
        image = torch.load(self.images[index])
        
        if self.subsample != -1 and self.transform is not None:
            
            image = self.transform(image)
            image = image.unsqueeze(0)
            image = F.interpolate(image, size =(self.subsample, self.subsample))
            image = image.squeeze(0)
            image = image.to(torch.float32)
        
        label = self.labels[index]
        return image, (self.time[index], self.event[index])
    
    def __len__(self):
        return len(self.pathid)
    
def modify_weights(weight_file_path, in_chans, patch_size=16):
    weights = torch.load(weight_file_path)["state_dict"]
    new_dict = OrderedDict()
    for k, v, in weights.items():
        new_key = k[7:]
        new_dict[new_key] = v

    conv1_name = "vit.patch_embed.proj"
    conv1_weight = new_dict[conv1_name + '.weight']
    conv1_type = conv1_weight.dtype
    conv1_weight = conv1_weight.float()
    O, I, J, K = conv1_weight.shape
    if I != 3:
        print('Deleting first conv (%s) from pretrained weights.' % conv1_name)
        del state_dict[conv1_name + '.weight']
        strict = False
    else:
        # NOTE this strategy should be better than random init, but there could be other combinations of
        # the original RGB input layer weights that'd work better for specific cases.
        print('Repeating first conv (%s) weights in channel dim.' % conv1_name)
        repeat = int(math.ceil(in_chans / 3))
        conv1_weight = conv1_weight.repeat(1, repeat, 1, 1)[:, :in_chans, :, :]
        conv1_weight *= (3 / float(in_chans))
        print('Resizing first conv (%s) weights in patch size.' % conv1_name)
        conv1_weight = F.interpolate(conv1_weight, size =(patch_size, patch_size))
        conv1_weight = conv1_weight.to(conv1_type)
        new_dict[conv1_name + '.weight'] = conv1_weight
    
    return new_dict

def modify_weights_surv(weight_file_path, in_chans, patch_size=16):
    if torch.cuda.is_available():
        weights = torch.load(weight_file_path)
    else:
        weights = torch.load(weight_file_path, map_location=torch.device('cpu'))
    new_dict = OrderedDict()
    for k, v, in weights.items():
        if k.startswith("module"):
            new_key = k[7:]
        else:
            new_key = k
        new_dict[new_key] = v

    conv1_name = "vit.patch_embed.proj"
    conv1_weight = new_dict[conv1_name + '.weight']
    conv1_type = conv1_weight.dtype
    conv1_weight = conv1_weight.float()
    O, I, J, K = conv1_weight.shape
    if I != 3:
        print('Deleting first conv (%s) from pretrained weights.' % conv1_name)
        del state_dict[conv1_name + '.weight']
        strict = False
    else:
        # NOTE this strategy should be better than random init, but there could be other combinations of
        # the original RGB input layer weights that'd work better for specific cases.
        print('Repeating first conv (%s) weights in channel dim.' % conv1_name)
        repeat = int(math.ceil(in_chans / 3))
        conv1_weight = conv1_weight.repeat(1, repeat, 1, 1)[:, :in_chans, :, :]
        conv1_weight *= (3 / float(in_chans))
        print('Resizing first conv (%s) weights in patch size.' % conv1_name)
        conv1_weight = F.interpolate(conv1_weight, size =(patch_size, patch_size))
        conv1_weight = conv1_weight.to(conv1_type)
        new_dict[conv1_name + '.weight'] = conv1_weight
    
    return new_dict
