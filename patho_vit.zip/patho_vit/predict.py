import torch
import torch.nn.functional as F
import torchvision.transforms as transforms
import numpy as np
from skimage.transform import resize
import cv2
from PIL import Image
import matplotlib.pyplot as plt
from collections import OrderedDict
import openslide
from .IDX2CLS import IDX2CLS
import os

from .vit_explain import vit_base_patch16_384 as patho_vit
from .ViT_explanation_generator import LRP


def predict(slide_right, weight_file_path):
    model = patho_vit(img_size=96, in_chans=1000, patch_size=4, num_classes=3)
    
    weights = torch.load(weight_file_path)["state_dict"]
    new_dict = OrderedDict()
    for k, v, in weights.items():
        if "vit.head.weight" in k:
            new_dict["head1.weight"] = v
        elif "vit.head.bias" in k:
            new_dict["head1.bias"] = v
        elif "fc.weight" in k:
            new_dict["head2.weight"] = v
        elif "fc.bias" in k:
            new_dict["head2.bias"] = v      
        else:
            new_key = k[11:]
            new_dict[new_key] = v
    
    model.load_state_dict(new_dict)
    model.eval()

    #slide_right = slide_right.to(torch.float32)
    output = model(slide_right)
    return output, model

def print_classes(predictions, **kwargs):
    prob = torch.softmax(predictions, dim=1)
    class_indices = predictions.data.topk(3, dim=1)[1][0].tolist()
    # 输出值.data.topk返回两行数值，第一行为原始预测值，第二行为索引值，形状为（1，k），
    # 用[0]消去形状，用tolist变成列表

    max_str_len = 0
    class_names = []

    for cls_idx in class_indices:
        class_names.append(IDX2CLS[cls_idx])
        if len(IDX2CLS[cls_idx]) > max_str_len:
            max_str_len = len(IDX2CLS[cls_idx])

    print("Total 3 classes:")
    for cls_idx in class_indices:
        output_string = '\t{} : {}'.format(cls_idx, IDX2CLS[cls_idx])
        output_string += ' ' * (max_str_len - len(IDX2CLS[cls_idx])) + '\t\t'
        output_string += 'value = {:.3f}\t prob = {:.1f}%'.format(predictions[0, cls_idx], 100 * prob[0, cls_idx])
        print(output_string)

def slide4observe(slide_name):
    slide = openslide.OpenSlide(os.path.join("/data2/ad/store_1/" + slide_name))
    m, n = slide.dimensions

    scale = 384 / min(m, n)
    m = int(m * scale)
    n = int(n * scale)

    slide_thumbnail = slide.get_thumbnail((m, n))
    
    tile = np.array(slide_thumbnail)

    #plt.imshow(slide_thumbnail)
    #plt.imsave("test.png", tile)

    return tile

def slide4network(slide_name):
    trans = transforms.ToTensor()
    
    slide = torch.load(os.path.join("./store_4", slide_name + ".db"))
    slide = trans(slide)
    slide = slide.unsqueeze(0)
    slide = F.interpolate(slide, size =(96, 96))
    return slide.to(torch.float32)

def heatmap(slide_left, slide_right, model, class_index=None, method="transformer_attribution"):
    #    transformer_attribution = attribution_generator.generate_LRP(original_image.unsqueeze(0).cuda(), method="transformer_attribution", index=class_index).detach()
    attribution_generator = LRP(model)
    transformer_attribution = attribution_generator.generate_LRP(slide_right, method=method, index=class_index).detach()
    
    if method == "full":
        transformer_attribution = transformer_attribution.squeeze(0)
        
    elif method != "full":
        transformer_attribution = transformer_attribution.reshape(1, 1, 24, 24)
        transformer_attribution = torch.nn.functional.interpolate(transformer_attribution, scale_factor=16, mode='bilinear')
        #    transformer_attribution = transformer_attribution.reshape(384, 384).cuda().data.cpu().numpy()    
        transformer_attribution = transformer_attribution.reshape(384, 384).data.cpu().numpy()
    
    transformer_attribution = (transformer_attribution - transformer_attribution.min()) / (transformer_attribution.max() - transformer_attribution.min())
    
    slide_left = resize(slide_left, (384, 384))
    image_transformer_attribution = (slide_left - slide_left .min()) / (slide_left .max() - slide_left .min())
    vis = show_cam_on_image(image_transformer_attribution, transformer_attribution)
    vis =  np.uint8(255 * vis)
    vis = cv2.cvtColor(np.array(vis), cv2.COLOR_RGB2BGR)
    return vis

# create heatmap from mask on image
def show_cam_on_image(img, mask):
    heatmap = cv2.applyColorMap(np.uint8(255 * mask), cv2.COLORMAP_JET)
    heatmap = np.float32(heatmap) / 255
    cam = heatmap + np.float32(img)
    cam = cam / np.max(cam)
    return cam











