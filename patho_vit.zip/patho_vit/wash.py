import glob
import os
import shutil
import cv2
import pandas as pd

def wash(path, var=500, patch_size=384):
    # 删除空房间
    # 首先删除所有.dzi格式的文件
    dzi_file = glob.glob(os.path.join(path, "store_2", "*.dzi"))
    for dzi in dzi_file:    
        os.remove(dzi)

    # 再删除白片和边角料
    pathid = [f for f in os.listdir(os.path.join(path, "store_2")) if not f.startswith(".")]
    empty = []
    white = []
    irregular = []
    examined_ids = []
    for i, id in enumerate(pathid):
        print("{} has now been examined".format(id))
        patches = glob.glob(os.path.join(path, "store_2", str(id), "0", "*.jpeg"))
        if len(patches) == 0:
            empty.append(id)
            shutil.rmtree(os.path.join(path, "store_2", str(id))) 
        else:
            for j, patch in enumerate(patches):
                image = cv2.imread(patch)
                if image.var() < 500:
                    white.append(patch)
                    os.remove(patch)
                elif image.shape[0] < patch_size:
                    irregular.append(patch)
                    os.remove(patch)
                elif image.shape[1] < patch_size:
                    irregular.append(patch)
                    os.remove(patch)
        
                if (j + 1) % 1000 == 0:
                    print("{} patches have been examined".format(n+1))
                
        examined_ids.append(id)
        if (i + 1) % 20 == 0:
            print("{} patients have been examined".format(i+1))

    c = {"examined_ids": examined_ids}
    df = pd.DataFrame(c)
    df.to_csv("./broken/examined_ids.txt", sep="\t")
    # 因样本量过大，此处需保存成txt格式
        
    c = {"empty": empty}
    df = pd.DataFrame(c)
    df.to_csv("./broken/empty.txt", sep = "\t")
                
    c = {"white": white}
    df = pd.DataFrame(c)
    df.to_csv("./broken/white.txt", sep = "\t")

    c = {"irregular": irregular}
    df = pd.DataFrame(c)
    df.to_csv("./broken/irregular.txt", sep = "\t")
    print("We have washed the slides!")
    examined_catalog = "broken/examined_ids.txt"
    return examined_catalog

def wash_again(path, examined_catalog, var=500, patch_size=384):
    pathid = [f for f in os.listdir(os.path.join(path, "store_2")) if not f.startswith(".")]
    df = pd.read_csv(examined_catalog, sep = "\t")
    examined_ids = df["examined_ids"].tolist()

    empty = []
    white = []
    irregular = []
    examined_ids_1 = []
    for i, id in enumerate(pathid):
        if id not in examined_ids:
            print("{} has now been examined".format(id))
            patches = glob.glob(os.path.join(path, "store_2", str(id), "0", "*.jpeg"))
            if len(patches) == 0:
                empty.append(id)
                shutil.rmtree(os.path.join(path, "store_2", str(id))) 
            else:
                for j, patch in enumerate(patches):
                    image = cv2.imread(patch)
                    if image.var() < 500:
                        white.append(patch)
                        os.remove(patch)
                    elif image.shape[0] < patch_size:
                        irregular.append(patch)
                        os.remove(patch)
                    elif image.shape[1] < patch_size:
                        irregular.append(patch)
                        os.remove(patch)
        
                    if (j + 1) % 1000 == 0:
                        print("{} patches have been examined".format(n+1))
                
        examined_ids_1.append(id)
        if (i + 1) % 20 == 0:
            print("{} patients have been examined".format(i+1))

    c = {"examined_ids_1": examined_ids_1}
    df = pd.DataFrame(c)
    df.to_csv("./broken/examined_again_ids.txt", sep="\t", mode = "a", header = None)
    # 因样本量过大，此处需保存成txt格式
        
    c = {"empty": empty}
    df = pd.DataFrame(c)
    df.to_csv("./broken/empty.txt", sep = "\t", mode = "a", header = None)
                
    c = {"white": white}
    df = pd.DataFrame(c)
    df.to_csv("./broken/white.txt", sep = "\t", mode = "a", header = None)

    c = {"irregular": irregular}
    df = pd.DataFrame(c)
    df.to_csv("./broken/irregular.txt", sep = "\t", mode = "a", header = None)
    print("We have washed the slides again!")
    examined_again_catalog = "broken/examined_again_ids.txt"
    return examined_again_catalog

