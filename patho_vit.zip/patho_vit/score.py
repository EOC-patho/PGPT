def score():
    print("we have given the score!")