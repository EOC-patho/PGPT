import cv2
import torch
import torch.nn as nn
import pandas as pd
from PIL import Image
from collections import OrderedDict
from .vit import vit_base_patch16_384 as vit
from .vit import vit_large_patch16_384 as vit_large
from .ViT_explanation_generator import LRP
from .layers_ours import Linear

# 构建数据集
class pathovitdataset(torch.utils.data.Dataset):
    def __init__(self, libraryfile = "", transform=None):
        file = torch.load(libraryfile)
        # 原始表格一个病人一行，一共三列，第一列为病理号，
        # 每行的第二列为一个列表，其中是每个补丁的路径，
        # 第三列为标签值
        self.labels = file["labels"]
        
        patientIDXs = []
        patches = []
        for i, p in enumerate(file["images"]):
            patientIDXs.extend([i] * len(p))
            # 此处的[i] * 并不是乘以，是复制的意思，意思是在新建的表格中，若第一个病人有4000张补丁，则前4000行的序号都是0
            # 这么做的好处是可以根据这个唯一的索引号（类似住院号）返回原表格，查找到对应的标签值
            patches.extend(p)
        
        self.patientIDXs = patientIDXs
        self.patches = patches
        self.transform = transform
    
    def __getitem__(self, index):
        patch = self.patches[index]
        img = Image.open(patch)
        
        if self.transform is not None:
            img = self.transform(img)
        
        patientIDX = self.patientIDXs[index]
        label = self.labels[patientIDX]
        return img, label
    
    def __len__(self):
        return len(self.patches)

class patho_vit(nn.Module):
    def __init__(self, img_size = 384, patch_size = 16, in_chans=3, num_classes=2, pretrained=True):
        super().__init__()
        self.vit = vit(pretrained=pretrained, img_size=img_size, in_chans=in_chans, patch_size = patch_size)
        self.fc = Linear(1000, num_classes)
        
    def forward(self, x):
        x = self.vit(x)
        return self.fc(x), x
    
class patho_vit_large(nn.Module):
    def __init__(self, img_size = 384, patch_size = 16, in_chans=3, num_classes=2, pretrained=False):
        super().__init__()
        self.vit = vit_large(pretrained=pretrained, img_size=img_size, in_chans=in_chans, patch_size = patch_size)
        self.fc = Linear(1000, num_classes)
        
    def forward(self, x):
        x = self.vit(x)
        return self.fc(x), x

# 为了使用pycox生存包，这里的模型只返回输出值，没有特征值
class patho_vit2(nn.Module):
    def __init__(self, img_size = 384, patch_size = 16, in_chans=3, depth=24, num_classes=2, pretrained=True):
        super().__init__()
        self.vit = vit(pretrained=pretrained, img_size=img_size, in_chans=in_chans, patch_size = patch_size)
        self.fc = Linear(1000, num_classes)
        
    def forward(self, x):
        x = self.vit(x)
        return self.fc(x)

def P2S(model_file_path):
    if torch.cuda.is_available():
        original_dict = torch.load(model_file_path)["state_dict"]
    else:
        original_dict = torch.load(model_file_path, map_location=torch.device('cpu'))["state_dict"]
    new_dict = OrderedDict()
    for k, v, in original_dict.items():
        new_key = k[7:]
        # 使用带两块GPU显卡的机器平行训练出的权重，前面自带module:，因此，将权重部署到CPU上时，需要将这7个字节删除
        new_dict[new_key] = v
    return new_dict

def P2S2(model_file_path):
    if torch.cuda.is_available():
        original_dict = torch.load(model_file_path)
    else:
        original_dict = torch.load(model_file_path, map_location=torch.device('cpu'))
    new_dict = OrderedDict()
    for k, v, in original_dict.items():
        if k.startswith("module"):
            new_key = k[7:]
        # 使用带两块GPU显卡的机器平行训练出的权重，前面自带module:，因此，将权重部署到CPU上时，需要将这7个字节删除
        else:
            new_key = k
        new_dict[new_key] = v
    return new_dict