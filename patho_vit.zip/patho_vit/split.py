import os
import glob
import pandas as pd
from sklearn.model_selection import train_test_split
import torch

def exists(val):
    return val is not None

def split(path=None, label_csv = None, test_size=0.2, sample_size = None):
    #pathid_orig = [f for f in os.listdir(os.path.join(path, "store_3")) if not f.startswith(".")]
    pathid_orig = [f[:-6] for f in os.listdir(os.path.join(path, "store_3")) if not f.startswith(".")]
    # 【:-6】的原因：pyvips切割wsi后，生成的文件自动加上了后缀_files,正好是6个字节
    #pathid_orig = [f[:-6] for f in os.listdir(os.path.join(path, "pseudo_store_3")) if not f.startswith(".")]
    
    if exists(label_csv):
        df_label = pd.read_excel(label_csv, index_col = "pathid")
    pathid = []
    images = []
    labels = []
    for i, id in enumerate(pathid_orig):
        if len(glob.glob(os.path.join(path, "store_3", str(id) + "_files","0", "*.jpeg"))) != 0:
            pathid.append(id)
            # 若生成的csv中的images为空缺，需检查图片的格式是否正确。例如，需要区分.jpeg和.jpg
            #重要提示：注意最后的文件后缀。images.append(glob.glob(os.path.join(path, "store_3", str(id) + "_files","0", "*.jpeg")))
            images.append(glob.glob(os.path.join(path, "store_3", str(id) + "_files","0", "*.jpeg")))
            if exists(label_csv):
                labels.append(df_label.loc[id]["labels"])
            else:
                labels.append(1e-6)
        else:
            pathid_orig_2 = [f for f in os.listdir(os.path.join(path, "store_3", str(id) + "_files")) if not f.startswith(".")]
            for j, id_2 in enumerate(pathid_orig_2):
                pathid.append(id_2)
                images.append(glob.glob(os.path.join(path, "store_3", str(id) + "_files", str(id_2), "0", "*.jpeg")))
                if exists(label_csv):
                    labels.append(df_label.loc[id]["labels"])
                else:
                    labels.append(1e-6)
    c = {"pathid": pathid, "images": images, "labels": labels}
    df = pd.DataFrame(c)

    index_train, index_valid = train_test_split(range(len(df)), test_size =test_size)
    df_train = df.loc[index_train].reset_index(drop = True)
    if exists(sample_size):
        df_train = df_train.loc[:int(sample_size - 1)]
    df_valid = df.loc[index_valid].reset_index(drop = True)

    df_train.to_csv("files/store_3_train.csv", index=False, encoding="utf_8_sig")
    torch.save(df_train.to_dict(orient='list'), "files/store_3_train.db")

    df_valid.to_csv("files/store_3_valid.csv", index=False, encoding="utf_8_sig")
    torch.save(df_valid.to_dict(orient='list'), "files/store_3_valid.db")

    print("We have split the datasets!")
    train_file = "store_3_train.csv"
    valid_file = "store_3_valid.csv"
    return train_file, valid_file

def split2(path=None, label_csv = None, test_size=0.2, sample_size = None):
    #pathid_orig = [f for f in os.listdir(os.path.join(path, "store_3")) if not f.startswith(".")]
    pathid_orig = [f[:-6] for f in os.listdir(os.path.join(path, "store_4")) if not f.startswith(".")]
    # 【:-6】的原因：pyvips切割wsi后，生成的文件自动加上了后缀_files,正好是6个字节
    #pathid_orig = [f[:-6] for f in os.listdir(os.path.join(path, "pseudo_store_3")) if not f.startswith(".")]
    
    if exists(label_csv):
        df_label = pd.read_csv(label_csv, index_col = "pathid")
    pathid = []
    images = []
    labels = []
    for i, id in enumerate(pathid_orig):
        if len(glob.glob(os.path.join(path, "store_4", str(id) + "_files","0", "*.jpeg"))) != 0:
            pathid.append(id)
            # 若生成的csv中的images为空缺，需检查图片的格式是否正确。例如，需要区分.jpeg和.jpg
            #重要提示：注意最后的文件后缀。images.append(glob.glob(os.path.join(path, "store_3", str(id) + "_files","0", "*.jpeg")))
            images.append(glob.glob(os.path.join(path, "store_4", str(id) + "_files","0", "*.jpeg")))
            if exists(label_csv):
                labels.append(df_label.loc[id]["labels"])
            else:
                labels.append(1e-6)
        else:
            pathid_orig_2 = [f for f in os.listdir(os.path.join(path, "store_4", str(id) + "_files")) if not f.startswith(".")]
            for j, id_2 in enumerate(pathid_orig_2):
                pathid.append(id_2)
                images.append(glob.glob(os.path.join(path, "store_4", str(id) + "_files", str(id_2), "0", "*.jpeg")))
                if exists(label_csv):
                    labels.append(df_label.loc[id]["labels"])
                else:
                    labels.append(1e-6)
    c = {"pathid": pathid, "images": images, "labels": labels}
    df = pd.DataFrame(c)

    index_train, index_valid = train_test_split(range(len(df)), test_size =test_size)
    df_train = df.loc[index_train].reset_index(drop = True)
    if exists(sample_size):
        df_train = df_train.loc[:int(sample_size - 1)]
    df_valid = df.loc[index_valid].reset_index(drop = True)

    df_train.to_csv("files_label/store_4_train.csv", index=False, encoding="utf_8_sig")
    torch.save(df_train.to_dict(orient='list'), "files_label/store_4_train.db")

    df_valid.to_csv("files_label/store_4_valid.csv", index=False, encoding="utf_8_sig")
    torch.save(df_valid.to_dict(orient='list'), "files_label/store_4_valid.db")

    print("We have split the datasets!")
    train_file = "store_4_train.csv"
    valid_file = "store_4_valid.csv"
    return train_file, valid_file

def split_surv(path, label_csv, test_size):
    #pathid_orig = [f for f in os.listdir(os.path.join(path, "store_3")) if not f.startswith(".")]
    pathid_orig = [f[:-6] for f in os.listdir(os.path.join(path, "store_3")) if not f.startswith(".")]
    # 【:-6】的原因：pyvips切割wsi后，生成的文件自动加上了后缀_files,正好是6个字节
    #pathid_orig = [f[:-6] for f in os.listdir(os.path.join(path, "pseudo_store_3")) if not f.startswith(".")]

    df_label = pd.read_excel(label_csv, index_col = "pathid")
    pathid = []
    images = []
    labels = []
    time = []
    event = []
    for i, id in enumerate(pathid_orig):
        pathid.append(id)
        # 若生成的csv中的images为空缺，需检查图片的格式是否正确。例如，需要区分.jpeg和.jpg
        #重要提示：注意最后的文件后缀。images.append(glob.glob(os.path.join(path, "store_3", str(id) + "_files","0", "*.jpeg")))
        images.append(glob.glob(os.path.join(path, "store_3", str(id) + "_files","0", "*.jpg")))
        labels.append(df_label.loc[id]["labels"])
        time.append(df_label.loc[id]["time"])
        event.append(df_label.loc[id]["event"])
    c = {"pathid": pathid, "images": images, "labels": labels, "time": time, "event":event}
    df = pd.DataFrame(c)

    index_train, index_valid = train_test_split(range(len(df)), test_size =test_size)
    df_train = df.loc[index_train].reset_index(drop = True)
    df_valid = df.loc[index_valid].reset_index(drop = True)

    df_train.to_csv("files/store_3_train_surv.csv", index=False, encoding="utf_8_sig")
    torch.save(df_train.to_dict(orient='list'), "files/store_3_train_surv.db")

    df_valid.to_csv("files/store_3_valid_surv.csv", index=False, encoding="utf_8_sig")
    torch.save(df_valid.to_dict(orient='list'), "files/store_3_valid_surv.db")

    print("We have split the datasets!")
    train_file = "store_3_train_surv.csv"
    valid_file = "store_3_valid_surv.csv"
    return train_file, valid_file