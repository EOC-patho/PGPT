import os
import pandas as pd
import glob
import pyvips

def catalog(path):
    # 做出几个空房间
    if not os.path.exists(os.path.join(path, "store_1")):
        os.makedirs(os.path.join(path, "store_1"))

    if not os.path.exists(os.path.join(path, "store_2")):
        os.makedirs(os.path.join(path, "store_2"))

    if not os.path.exists(os.path.join(path, "store_3")):
        os.makedirs(os.path.join(path, "store_3"))

    if not os.path.exists(os.path.join(path, "store_4")):
        os.makedirs(os.path.join(path, "store_4"))

    if not os.path.exists(os.path.join(path, "store_5")):
        os.makedirs(os.path.join(path, "store_5"))

    if not os.path.exists(os.path.join(path, "broken")):
        os.makedirs(os.path.join(path, "broken"))

    if not os.path.exists(os.path.join(path, "files")):
        os.makedirs(os.path.join(path, "files"))

    if not os.path.exists("output"):
        os.makedirs("output")
    
    pathid = []
    pathids = []

    pathid_total = [f for f in os.listdir(os.path.join(path + "/store_1")) if not f.startswith(".")]
    # 所有图片，但不包括隐藏文件
    pathid_bif = [f for f in pathid_total if f.endswith("bif")]
    pathid_mrxs = [f for f in pathid_total if f.endswith("mrxs")]
    pathid_mrxs = [f for f in pathid_total if f.endswith("jpg")]
    # 不同扫描仪会生成不同的后缀，需要都加上
    pathid.extend(pathid_bif)
    pathid.extend(pathid_mrxs)

    pathids_bif = glob.glob(os.path.join(path, "store_1", "*.bif"))
    pathids_mrxs = glob.glob(os.path.join(path, "store_1", "*.mrxs"))
    pathids_mrxs = glob.glob(os.path.join(path, "store_1", "*.jpg"))
    # 不同扫描仪会生成不同的后缀，需要都加上    
    pathids.extend(pathids_bif)
    pathids.extend(pathids_mrxs)

    c = {"pathid": pathid, "pathids": pathids}
    df = pd.DataFrame(c)
    df.to_csv("files/store_1.csv", encoding="utf_8_sig", index=None) # utf_8_sig可避免乱码
    print("Patients ids and slide paths have been saved as files/store_1.csv !")
    return "files/store_1.csv"

def crop(path, catalog, patch_size=384):
    df = pd.read_csv(catalog)
    pathid = df["pathid"]
    pathids = df["pathids"]
    broken = []
    for i, image in enumerate(pathids):
        try:
            img = pyvips.Image.new_from_file(image, access="sequential")
        except:
            print("{} is not allowed".format(image))
            broken.append(image)
            continue
        try:
            #img.dzsave(os.path.join(path,"store_2", str(pathid[i])), depth="one", tile_size=384, overlap=0)
            img.dzsave(os.path.join(path,"store_2", str(pathid[i])), depth="one", tile_size=patch_size, overlap=0)
        except:
            print("{} cannot be save".format(image))
            broken.append(image)
            continue

    c = {"broken": broken}
    df = pd.DataFrame(c)
    df.to_csv("./broken/broken.txt", sep="\t")
    print("We have cropped the slides and record the broken catalog in broken/broken.txt !")
    return "broken/broken.txt"
    

