import torch
import torchvision.transforms as transforms
from torchvision.utils import save_image
import torchstain
import cv2
import os
import glob
import matplotlib.pyplot as plt

def stain(path, sample):
    # 制作仓库3
    # 制作染色器

    target = cv2.cvtColor(cv2.imread(sample), cv2.COLOR_BGR2RGB)
    trans = transforms.Compose([
        transforms.ToTensor(),
        transforms.Lambda(lambda x: x*255)
    ])
    torch_normalizer = torchstain.normalizers.ReinhardNormalizer(backend = "torch", method ="modified")
    torch_normalizer.fit(trans(target))

    pathid = [f for f in os.listdir(os.path.join(path, "store_2")) if not f.startswith(".")]
    for i, id in enumerate(pathid):
        print("{} slide has now been stained".format(id))
        patches = glob.glob(os.path.join(path, "store_2", str(id), "0", "*.jpeg"))
        for patch in patches:
            img = cv2.cvtColor(cv2.imread(patch), cv2.COLOR_BGR2RGB)
            img = trans(img)
            try:
                img = torch_normalizer.normalize(I=img)
                if not os.path.exists(os.path.join(path, "store_3", str(id), "0")):
                    os.makedirs(os.path.join(path, "store_3", str(id), "0"))
                plt.imsave(os.path.join(path, "store_3", str(id), "0", patch.split("/")[-1]), img.numpy())
            except:
                print("{} patch cannot be stained".format(patch))
    print("We have stained the slides!")
    stain_number = len(pathid)
    return stain_number

def stain_again(path, sample):
    target = cv2.cvtColor(cv2.imread(sample), cv2.COLOR_BGR2RGB)
    trans = transforms.Compose([
        transforms.ToTensor(),
        transforms.Lambda(lambda x: x*255)
    ])
    torch_normalizer = torchstain.normalizers.ReinhardNormalizer(backend = "torch", method ="modified")
    torch_normalizer.fit(trans(target))

    # 找出仓库2和仓库3之间的差异，也就是需要重新染色的片子
    store_2_id = os.listdir(os.path.join(path, "store_2"))
    store_3_id = os.listdir(os.path.join(path, "store_3"))
    overlook = []
    for i, id in enumerate(store_2_id):
        if id not in store_3_id:
            print(id)
            overlook.append(id)

    for i, id in enumerate(overlook):
        print("{} slide has now been stained".format(id))
        patches = glob.glob(os.path.join(path, "store_2", str(id), "0", "*.jpeg"))
        for patch in patches:
            img = cv2.cvtColor(cv2.imread(patch), cv2.COLOR_BGR2RGB)
            img = trans(img)
            try:
                img = torch_normalizer.normalize(I=img)
                if not os.path.exists(os.path.join(path, "store_3", str(id), "0")):
                    os.makedirs(os.path.join(path, "store_3", str(id), "0"))
                plt.imsave(os.path.join(path, "store_3", str(id), "0", patch.split("/")[-1]), img.numpy())
            except:
                print("{} patch cannot be stained".format(patch))
    print("We have stained the slides again!")
    stain_again_number = len(overlook)
    return stain_again_number