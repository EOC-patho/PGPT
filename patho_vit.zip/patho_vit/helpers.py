""" Model creation / weight loading / state_dict helpers

Hacked together by / Copyright 2020 Ross Wightman
"""
import logging
import os
import math
from collections import OrderedDict
from copy import deepcopy
from typing import Callable

import torch
import torch.nn as nn
import torch.utils.model_zoo as model_zoo
import torch.nn.functional as F

_logger = logging.getLogger(__name__)


def load_state_dict(checkpoint_path, use_ema=False):
    if checkpoint_path and os.path.isfile(checkpoint_path):
        checkpoint = torch.load(checkpoint_path, map_location='cpu')
        state_dict_key = 'state_dict'
        if isinstance(checkpoint, dict):
            if use_ema and 'state_dict_ema' in checkpoint:
                state_dict_key = 'state_dict_ema'
        if state_dict_key and state_dict_key in checkpoint:
            new_state_dict = OrderedDict()
            for k, v in checkpoint[state_dict_key].items():
                # strip `module.` prefix
                name = k[7:] if k.startswith('module') else k
                new_state_dict[name] = v
            state_dict = new_state_dict
        else:
            state_dict = checkpoint
        _logger.info("Loaded {} from checkpoint '{}'".format(state_dict_key, checkpoint_path))
        return state_dict
    else:
        _logger.error("No checkpoint found at '{}'".format(checkpoint_path))
        raise FileNotFoundError()


def load_checkpoint(model, checkpoint_path, use_ema=False, strict=True):
    state_dict = load_state_dict(checkpoint_path, use_ema)
    model.load_state_dict(state_dict, strict=strict)


def resume_checkpoint(model, checkpoint_path, optimizer=None, loss_scaler=None, log_info=True):
    resume_epoch = None
    if os.path.isfile(checkpoint_path):
        checkpoint = torch.load(checkpoint_path, map_location='cpu')
        if isinstance(checkpoint, dict) and 'state_dict' in checkpoint:
            if log_info:
                _logger.info('Restoring model state from checkpoint...')
            new_state_dict = OrderedDict()
            for k, v in checkpoint['state_dict'].items():
                name = k[7:] if k.startswith('module') else k
                new_state_dict[name] = v
            model.load_state_dict(new_state_dict)

            if optimizer is not None and 'optimizer' in checkpoint:
                if log_info:
                    _logger.info('Restoring optimizer state from checkpoint...')
                optimizer.load_state_dict(checkpoint['optimizer'])

            if loss_scaler is not None and loss_scaler.state_dict_key in checkpoint:
                if log_info:
                    _logger.info('Restoring AMP loss scaler state from checkpoint...')
                loss_scaler.load_state_dict(checkpoint[loss_scaler.state_dict_key])

            if 'epoch' in checkpoint:
                resume_epoch = checkpoint['epoch']
                if 'version' in checkpoint and checkpoint['version'] > 1:
                    resume_epoch += 1  # start at the next epoch, old checkpoints incremented before save

            if log_info:
                _logger.info("Loaded checkpoint '{}' (epoch {})".format(checkpoint_path, checkpoint['epoch']))
        else:
            model.load_state_dict(checkpoint)
            if log_info:
                _logger.info("Loaded checkpoint '{}'".format(checkpoint_path))
        return resume_epoch
    else:
        _logger.error("No checkpoint found at '{}'".format(checkpoint_path))
        raise FileNotFoundError()


def load_pretrained(model, cfg=None, in_chans=3, patch_size = 16, num_classes=1000, filter_fn=None, strict=True):
    if cfg is None:
        cfg = getattr(model, 'default_cfg')
    if cfg is None or 'url' not in cfg or not cfg['url']:
        _logger.warning("Pretrained model URL is invalid, using random initialization.")
        return

    state_dict = model_zoo.load_url(cfg['url'], progress=False, map_location='cpu')

    if filter_fn is not None:
        state_dict = filter_fn(state_dict)

    if in_chans == 1:
        conv1_name = cfg['first_conv']
        _logger.info('Converting first conv (%s) pretrained weights from 3 to 1 channel' % conv1_name)
        conv1_weight = state_dict[conv1_name + '.weight']
        # Some weights are in torch.half, ensure it's float for sum on CPU
        conv1_type = conv1_weight.dtype
        conv1_weight = conv1_weight.float()
        O, I, J, K = conv1_weight.shape
        if I > 3:
            assert conv1_weight.shape[1] % 3 == 0
            # For models with space2depth stems
            conv1_weight = conv1_weight.reshape(O, I // 3, 3, J, K)
            conv1_weight = conv1_weight.sum(dim=2, keepdim=False)
        else:
            conv1_weight = conv1_weight.sum(dim=1, keepdim=True)
        conv1_weight = conv1_weight.to(conv1_type)
        state_dict[conv1_name + '.weight'] = conv1_weight
    elif in_chans != 3:
        conv1_name = cfg['first_conv']
        conv1_weight = state_dict[conv1_name + '.weight']
        conv1_type = conv1_weight.dtype
        conv1_weight = conv1_weight.float()
        O, I, J, K = conv1_weight.shape
        if I != 3:
            _logger.warning('Deleting first conv (%s) from pretrained weights.' % conv1_name)
            del state_dict[conv1_name + '.weight']
            strict = False
        else:
            # NOTE this strategy should be better than random init, but there could be other combinations of
            # the original RGB input layer weights that'd work better for specific cases.
            _logger.info('Repeating first conv (%s) weights in channel dim.' % conv1_name)
            repeat = int(math.ceil(in_chans / 3))
            conv1_weight = conv1_weight.repeat(1, repeat, 1, 1)[:, :in_chans, :, :]
            conv1_weight *= (3 / float(in_chans))
            conv1_weight = F.interpolate(conv1_weight, size =(patch_size, patch_size))
            conv1_weight = conv1_weight.to(conv1_type)
            state_dict[conv1_name + '.weight'] = conv1_weight

    classifier_name = cfg['classifier']
    if num_classes == 1000 and cfg['num_classes'] == 1001:
        # special case for imagenet trained models with extra background class in pretrained weights
        classifier_weight = state_dict[classifier_name + '.weight']
        state_dict[classifier_name + '.weight'] = classifier_weight[1:]
        classifier_bias = state_dict[classifier_name + '.bias']
        state_dict[classifier_name + '.bias'] = classifier_bias[1:]
    elif num_classes != cfg['num_classes']:
        # completely discard fully connected for all other differences between pretrained and created model
        del state_dict[classifier_name + '.weight']
        del state_dict[classifier_name + '.bias']
        strict = False

    model.load_state_dict(state_dict, strict=True)


def extract_layer(model, layer):
    layer = layer.split('.')
    module = model
    if hasattr(model, 'module') and layer[0] != 'module':
        module = model.module
    if not hasattr(model, 'module') and layer[0] == 'module':
        layer = layer[1:]
    for l in layer:
        if hasattr(module, l):
            if not l.isdigit():
                module = getattr(module, l)
            else:
                module = module[int(l)]
        else:
            return module
    return module


def set_layer(model, layer, val):
    layer = layer.split('.')
    module = model
    if hasattr(model, 'module') and layer[0] != 'module':
        module = model.module
    lst_index = 0
    module2 = module
    for l in layer:
        if hasattr(module2, l):
            if not l.isdigit():
                module2 = getattr(module2, l)
            else:
                module2 = module2[int(l)]
            lst_index += 1
    lst_index -= 1
    for l in layer[:lst_index]:
        if not l.isdigit():
            module = getattr(module, l)
        else:
            module = module[int(l)]
    l = layer[lst_index]
    setattr(module, l, val)


def adapt_model_from_string(parent_module, model_string):
    separator = '***'
    state_dict = {}
    lst_shape = model_string.split(separator)
    for k in lst_shape:
        k = k.split(':')
        key = k[0]
        shape = k[1][1:-1].split(',')
        if shape[0] != '':
            state_dict[key] = [int(i) for i in shape]

    new_module = deepcopy(parent_module)
    for n, m in parent_module.named_modules():
        old_module = extract_layer(parent_module, n)
        if isinstance(old_module, nn.Conv2d) or isinstance(old_module, Conv2dSame):
            if isinstance(old_module, Conv2dSame):
                conv = Conv2dSame
            else:
                conv = nn.Conv2d
            s = state_dict[n + '.weight']
            in_channels = s[1]
            out_channels = s[0]
            g = 1
            if old_module.groups > 1:
                in_channels = out_channels
                g = in_channels
            new_conv = conv(
                in_channels=in_channels, out_channels=out_channels, kernel_size=old_module.kernel_size,
                bias=old_module.bias is not None, padding=old_module.padding, dilation=old_module.dilation,
                groups=g, stride=old_module.stride)
            set_layer(new_module, n, new_conv)
        if isinstance(old_module, nn.BatchNorm2d):
            new_bn = nn.BatchNorm2d(
                num_features=state_dict[n + '.weight'][0], eps=old_module.eps, momentum=old_module.momentum,
                affine=old_module.affine, track_running_stats=True)
            set_layer(new_module, n, new_bn)
        if isinstance(old_module, nn.Linear):
            # FIXME extra checks to ensure this is actually the FC classifier layer and not a diff Linear layer?
            num_features = state_dict[n + '.weight'][1]
            new_fc = nn.Linear(
                in_features=num_features, out_features=old_module.out_features, bias=old_module.bias is not None)
            set_layer(new_module, n, new_fc)
            if hasattr(new_module, 'num_features'):
                new_module.num_features = num_features
    new_module.eval()
    parent_module.eval()

    return new_module


def adapt_model_from_file(parent_module, model_variant):
    adapt_file = os.path.join(os.path.dirname(__file__), 'pruned', model_variant + '.txt')
    with open(adapt_file, 'r') as f:
        return adapt_model_from_string(parent_module, f.read().strip())


def build_model_with_cfg(
        model_cls: Callable,
        variant: str,
        pretrained: bool,
        default_cfg: dict,
        model_cfg: dict = None,
        feature_cfg: dict = None,
        pretrained_strict: bool = True,
        pretrained_filter_fn: Callable = None,
        **kwargs):
    pruned = kwargs.pop('pruned', False)
    features = False
    feature_cfg = feature_cfg or {}

    if kwargs.pop('features_only', False):
        features = True
        feature_cfg.setdefault('out_indices', (0, 1, 2, 3, 4))
        if 'out_indices' in kwargs:
            feature_cfg['out_indices'] = kwargs.pop('out_indices')

    model = model_cls(**kwargs) if model_cfg is None else model_cls(cfg=model_cfg, **kwargs)
    model.default_cfg = deepcopy(default_cfg)

    if pruned:
        model = adapt_model_from_file(model, variant)

    if pretrained:
        load_pretrained(
            model,
            num_classes=kwargs.get('num_classes', 0),
            in_chans=kwargs.get('in_chans', 3),
            filter_fn=pretrained_filter_fn, strict=pretrained_strict)

    if features:
        feature_cls = FeatureListNet
        if 'feature_cls' in feature_cfg:
            feature_cls = feature_cfg.pop('feature_cls')
            if isinstance(feature_cls, str):
                feature_cls = feature_cls.lower()
                if 'hook' in feature_cls:
                    feature_cls = FeatureHookNet
                else:
                    assert False, f'Unknown feature class {feature_cls}'
        model = feature_cls(model, **feature_cfg)

    return model

#def timm2luci(weight_path):
    if torch.cuda.is_available():
        old_dict = torch.load(weight_path)
    else:
        old_dict = torch.load(weight_path, map_location=torch.device('cpu'))
    
    new_dict = {}

    for k, v in list(old_dict.items()):
        name = k[7:] if k.startswith('module') else k
        new_dict[name] = v

    newer_dict = {}
    for k, v in new_dict.items():
        if "embed" in k:
            k = k.replace("embed", "embedding")
        if "patch" in k:
            k = k.replace("patch", "to_patch")
        if "embedding.proj.weight" in k:
            k = k.replace("embedding.proj.weight", "embedding.2.weight")
            v = v.reshape(768, 768)
        if "embedding.proj.bias" in k:
            k = k.replace("embedding.proj.bias", "embedding.2.bias")
    
        if "blocks" in k:
            k = k.replace("blocks", "transformer.layers")
    
        if "0.norm1" in k:
            k = k.replace("0.norm1", "0.0.norm")
        if "0.attn.qkv" in k:
            k = k.replace("0.attn.qkv", "0.0.fn.to_qkv")
        if "0.attn.proj" in k:
            k = k.replace("0.attn.proj", "0.0.fn.to_out.0")
        if "0.norm2" in k:
            k = k.replace("0.norm2", "0.1.norm")
        if "0.mlp.fc1" in k:
            k = k.replace("0.mlp.fc1", "0.1.fn.net.0")
        if "0.mlp.fc2" in k:
            k = k.replace("0.mlp.fc2", "0.1.fn.net.3")

        if "1.norm1" in k:
            k = k.replace("1.norm1", "1.0.norm")
        if "1.attn.qkv" in k:
            k = k.replace("1.attn.qkv", "1.0.fn.to_qkv")
        if "1.attn.proj" in k:
            k = k.replace("1.attn.proj", "1.0.fn.to_out.0")
        if "1.norm2" in k:
            k = k.replace("1.norm2", "1.1.norm")
        if "1.mlp.fc1" in k:
            k = k.replace("1.mlp.fc1", "1.1.fn.net.0")
        if "1.mlp.fc2" in k:
            k = k.replace("1.mlp.fc2", "1.1.fn.net.3")

    
        if "2.norm1" in k:
            k = k.replace("2.norm1", "2.0.norm")
        if "2.attn.qkv" in k:
            k = k.replace("2.attn.qkv", "2.0.fn.to_qkv")
        if "2.attn.proj" in k:
            k = k.replace("2.attn.proj", "2.0.fn.to_out.0")
        if "2.norm2" in k:
            k = k.replace("2.norm2", "2.1.norm")
        if "2.mlp.fc1" in k:
            k = k.replace("2.mlp.fc1", "2.1.fn.net.0")
        if "2.mlp.fc2" in k:
            k = k.replace("2.mlp.fc2", "2.1.fn.net.3")

        if "3.norm1" in k:
            k = k.replace("3.norm1", "3.0.norm")
        if "3.attn.qkv" in k:
            k = k.replace("3.attn.qkv", "3.0.fn.to_qkv")
        if "3.attn.proj" in k:
            k = k.replace("3.attn.proj", "3.0.fn.to_out.0")
        if "3.norm2" in k:
            k = k.replace("3.norm2", "3.1.norm")
        if "3.mlp.fc1" in k:
            k = k.replace("3.mlp.fc1", "3.1.fn.net.0")
        if "3.mlp.fc2" in k:
            k = k.replace("3.mlp.fc2", "3.1.fn.net.3")

        if "4.norm1" in k:
            k = k.replace("4.norm1", "4.0.norm")
        if "4.attn.qkv" in k:
            k = k.replace("4.attn.qkv", "4.0.fn.to_qkv")
        if "4.attn.proj" in k:
            k = k.replace("4.attn.proj", "4.0.fn.to_out.0")
        if "4.norm2" in k:
            k = k.replace("4.norm2", "4.1.norm")
        if "4.mlp.fc1" in k:
            k = k.replace("4.mlp.fc1", "4.1.fn.net.0")
        if "4.mlp.fc2" in k:
            k = k.replace("4.mlp.fc2", "4.1.fn.net.3")

        if "5.norm1" in k:
            k = k.replace("5.norm1", "5.0.norm")
        if "5.attn.qkv" in k:
            k = k.replace("5.attn.qkv", "5.0.fn.to_qkv")
        if "5.attn.proj" in k:
            k = k.replace("5.attn.proj", "5.0.fn.to_out.0")
        if "5.norm2" in k:
            k = k.replace("5.norm2", "5.1.norm")
        if "5.mlp.fc1" in k:
            k = k.replace("5.mlp.fc1", "5.1.fn.net.0")
        if "5.mlp.fc2" in k:
            k = k.replace("5.mlp.fc2", "5.1.fn.net.3")
        
        if "6.norm1" in k:
            k = k.replace("6.norm1", "6.0.norm")
        if "6.attn.qkv" in k:
            k = k.replace("6.attn.qkv", "6.0.fn.to_qkv")
        if "6.attn.proj" in k:
            k = k.replace("6.attn.proj", "6.0.fn.to_out.0")
        if "6.norm2" in k:
            k = k.replace("6.norm2", "6.1.norm")
        if "6.mlp.fc1" in k:
            k = k.replace("6.mlp.fc1", "6.1.fn.net.0")
        if "6.mlp.fc2" in k:
            k = k.replace("6.mlp.fc2", "6.1.fn.net.3")

        if "7.norm1" in k:
            k = k.replace("7.norm1", "7.0.norm")
        if "7.attn.qkv" in k:
            k = k.replace("7.attn.qkv", "7.0.fn.to_qkv")
        if "7.attn.proj" in k:
            k = k.replace("7.attn.proj", "7.0.fn.to_out.0")
        if "7.norm2" in k:
            k = k.replace("7.norm2", "7.1.norm")
        if "7.mlp.fc1" in k:
            k = k.replace("7.mlp.fc1", "7.1.fn.net.0")
        if "7.mlp.fc2" in k:
            k = k.replace("7.mlp.fc2", "7.1.fn.net.3")

        if "8.norm1" in k:
            k = k.replace("8.norm1", "8.0.norm")
        if "8.attn.qkv" in k:
            k = k.replace("8.attn.qkv", "8.0.fn.to_qkv")
        if "8.attn.proj" in k:
            k = k.replace("8.attn.proj", "8.0.fn.to_out.0")
        if "8.norm2" in k:
            k = k.replace("8.norm2", "8.1.norm")
        if "8.mlp.fc1" in k:
            k = k.replace("8.mlp.fc1", "8.1.fn.net.0")
        if "8.mlp.fc2" in k:
            k = k.replace("8.mlp.fc2", "8.1.fn.net.3")

        if "9.norm1" in k:
            k = k.replace("9.norm1", "9.0.norm")
        if "9.attn.qkv" in k:
            k = k.replace("9.attn.qkv", "9.0.fn.to_qkv")
        if "9.attn.proj" in k:
            k = k.replace("9.attn.proj", "9.0.fn.to_out.0")
        if "9.norm2" in k:
            k = k.replace("9.norm2", "9.1.norm")
        if "9.mlp.fc1" in k:
            k = k.replace("9.mlp.fc1", "9.1.fn.net.0")
        if "9.mlp.fc2" in k:
            k = k.replace("9.mlp.fc2", "9.1.fn.net.3")

        if "10.norm1" in k:
            k = k.replace("10.norm1", "10.0.norm")
        if "10.attn.qkv" in k:
            k = k.replace("10.attn.qkv", "10.0.fn.to_qkv")
        if "10.attn.proj" in k:
            k = k.replace("10.attn.proj", "10.0.fn.to_out.0")
        if "10.norm2" in k:
            k = k.replace("10.norm2", "10.1.norm")
        if "10.mlp.fc1" in k:
            k = k.replace("10.mlp.fc1", "10.1.fn.net.0")
        if "10.mlp.fc2" in k:
            k = k.replace("10.mlp.fc2", "10.1.fn.net.3")

        if "11.norm1" in k:
            k = k.replace("11.norm1", "11.0.norm")
        if "11.attn.qkv" in k:
            k = k.replace("11.attn.qkv", "11.0.fn.to_qkv")
        if "11.attn.proj" in k:
            k = k.replace("11.attn.proj", "11.0.fn.to_out.0")
        if "11.norm2" in k:
            k = k.replace("11.norm2", "11.1.norm")
        if "11.mlp.fc1" in k:
            k = k.replace("11.mlp.fc1", "11.1.fn.net.0")
        if "11.mlp.fc2" in k:
            k = k.replace("11.mlp.fc2", "11.1.fn.net.3")

        if "norm" in k and "transformer" not in k:
            k = k.replace("norm.weight", "head.0.weight")
            k = k.replace("norm.bias", "head.0.bias")
        if "head" in k:
            k = k.replace("head", "mlp_head.1")    
        if "mlp_head.1.0.weight" in k:
            k = k.replace("mlp_head.1.0.weight", "mlp_head.0.weight")    
        if "mlp_head.1.0.bias" in k:
            k = k.replace("mlp_head.1.0.bias", "mlp_head.0.bias")
    
        newer_dict[k] = v
    
    return newer_dict

def timm2luci(weight_path):
    if torch.cuda.is_available():
        old_dict = torch.load(weight_path)
    else:
        old_dict = torch.load(weight_path, map_location=torch.device('cpu'))
    
    new_dict = {}

    if "epoch" in list(old_dict.keys()):
        for k, v in list(old_dict["state_dict"].items()):
            name = k[11:] if k.startswith('module') else k # 此处的11删除了module.vit.
            new_dict[name] = v
    else:
        for k, v in list(old_dict.items()):
            
            name = k[7:] if k.startswith('module') else k
            new_dict[name] = v

    newer_dict = {}
    for k, v in list(new_dict.items()):
        if "embed" in k:
            k = k.replace("embed", "embedding")
        if "patch" in k:
            k = k.replace("patch", "to_patch")
        if "embedding.proj.weight" in k:
            k = k.replace("embedding.proj.weight", "embedding.2.weight")
            v = v.reshape(768, 768)
        if "embedding.proj.bias" in k:
            k = k.replace("embedding.proj.bias", "embedding.2.bias")
    
        if "blocks" in k:
            k = k.replace("blocks", "transformer.layers")
    
        if "0.norm1" in k:
            k = k.replace("0.norm1", "0.0.norm")
        if "0.attn.qkv" in k:
            k = k.replace("0.attn.qkv", "0.0.to_qkv")
        if "0.attn.proj" in k:
            k = k.replace("0.attn.proj", "0.0.to_out.0")
        if "0.norm2" in k:
            k = k.replace("0.norm2", "0.1.net.0")
        if "0.mlp.fc1" in k:
            k = k.replace("0.mlp.fc1", "0.1.net.1")
        if "0.mlp.fc2" in k:
            k = k.replace("0.mlp.fc2", "0.1.net.4")

        if "1.norm1" in k:
            k = k.replace("1.norm1", "1.0.norm")
        if "1.attn.qkv" in k:
            k = k.replace("1.attn.qkv", "1.0.to_qkv")
        if "1.attn.proj" in k:
            k = k.replace("1.attn.proj", "1.0.to_out.0")
        if "1.norm2" in k:
            k = k.replace("1.norm2", "1.1.net.0")
        if "1.mlp.fc1" in k:
            k = k.replace("1.mlp.fc1", "1.1.net.1")
        if "1.mlp.fc2" in k:
            k = k.replace("1.mlp.fc2", "1.1.net.4")

    
        if "2.norm1" in k:
            k = k.replace("2.norm1", "2.0.norm")
        if "2.attn.qkv" in k:
            k = k.replace("2.attn.qkv", "2.0.to_qkv")
        if "2.attn.proj" in k:
            k = k.replace("2.attn.proj", "2.0.to_out.0")
        if "2.norm2" in k:
            k = k.replace("2.norm2", "2.1.net.0")
        if "2.mlp.fc1" in k:
            k = k.replace("2.mlp.fc1", "2.1.net.1")
        if "2.mlp.fc2" in k:
            k = k.replace("2.mlp.fc2", "2.1.net.4")

        if "3.norm1" in k:
            k = k.replace("3.norm1", "3.0.norm")
        if "3.attn.qkv" in k:
            k = k.replace("3.attn.qkv", "3.0.to_qkv")
        if "3.attn.proj" in k:
            k = k.replace("3.attn.proj", "3.0.to_out.0")
        if "3.norm2" in k:
            k = k.replace("3.norm2", "3.1.net.0")
        if "3.mlp.fc1" in k:
            k = k.replace("3.mlp.fc1", "3.1.net.1")
        if "3.mlp.fc2" in k:
            k = k.replace("3.mlp.fc2", "3.1.net.4")

        if "4.norm1" in k:
            k = k.replace("4.norm1", "4.0.norm")
        if "4.attn.qkv" in k:
            k = k.replace("4.attn.qkv", "4.0.to_qkv")
        if "4.attn.proj" in k:
            k = k.replace("4.attn.proj", "4.0.to_out.0")
        if "4.norm2" in k:
            k = k.replace("4.norm2", "4.1.net.0")
        if "4.mlp.fc1" in k:
            k = k.replace("4.mlp.fc1", "4.1.net.1")
        if "4.mlp.fc2" in k:
            k = k.replace("4.mlp.fc2", "4.1.net.4")

        if "5.norm1" in k:
            k = k.replace("5.norm1", "5.0.norm")
        if "5.attn.qkv" in k:
            k = k.replace("5.attn.qkv", "5.0.to_qkv")
        if "5.attn.proj" in k:
            k = k.replace("5.attn.proj", "5.0.to_out.0")
        if "5.norm2" in k:
            k = k.replace("5.norm2", "5.1.net.0")
        if "5.mlp.fc1" in k:
            k = k.replace("5.mlp.fc1", "5.1.net.1")
        if "5.mlp.fc2" in k:
            k = k.replace("5.mlp.fc2", "5.1.net.4")
        
        if "6.norm1" in k:
            k = k.replace("6.norm1", "6.0.norm")
        if "6.attn.qkv" in k:
            k = k.replace("6.attn.qkv", "6.0.to_qkv")
        if "6.attn.proj" in k:
            k = k.replace("6.attn.proj", "6.0.to_out.0")
        if "6.norm2" in k:
            k = k.replace("6.norm2", "6.1.net.0")
        if "6.mlp.fc1" in k:
            k = k.replace("6.mlp.fc1", "6.1.net.1")
        if "6.mlp.fc2" in k:
            k = k.replace("6.mlp.fc2", "6.1.net.4")

        if "7.norm1" in k:
            k = k.replace("7.norm1", "7.0.norm")
        if "7.attn.qkv" in k:
            k = k.replace("7.attn.qkv", "7.0.to_qkv")
        if "7.attn.proj" in k:
            k = k.replace("7.attn.proj", "7.0.to_out.0")
        if "7.norm2" in k:
            k = k.replace("7.norm2", "7.1.net.0")
        if "7.mlp.fc1" in k:
            k = k.replace("7.mlp.fc1", "7.1.net.1")
        if "7.mlp.fc2" in k:
            k = k.replace("7.mlp.fc2", "7.1.net.4")

        if "8.norm1" in k:
            k = k.replace("8.norm1", "8.0.norm")
        if "8.attn.qkv" in k:
            k = k.replace("8.attn.qkv", "8.0.to_qkv")
        if "8.attn.proj" in k:
            k = k.replace("8.attn.proj", "8.0.to_out.0")
        if "8.norm2" in k:
            k = k.replace("8.norm2", "8.1.net.0")
        if "8.mlp.fc1" in k:
            k = k.replace("8.mlp.fc1", "8.1.net.1")
        if "8.mlp.fc2" in k:
            k = k.replace("8.mlp.fc2", "8.1.net.4")

        if "9.norm1" in k:
            k = k.replace("9.norm1", "9.0.norm")
        if "9.attn.qkv" in k:
            k = k.replace("9.attn.qkv", "9.0.to_qkv")
        if "9.attn.proj" in k:
            k = k.replace("9.attn.proj", "9.0.to_out.0")
        if "9.norm2" in k:
            k = k.replace("9.norm2", "9.1.net.0")
        if "9.mlp.fc1" in k:
            k = k.replace("9.mlp.fc1", "9.1.net.1")
        if "9.mlp.fc2" in k:
            k = k.replace("9.mlp.fc2", "9.1.net.4")

        if "10.norm1" in k:
            k = k.replace("10.norm1", "10.0.norm")
        if "10.attn.qkv" in k:
            k = k.replace("10.attn.qkv", "10.0.to_qkv")
        if "10.attn.proj" in k:
            k = k.replace("10.attn.proj", "10.0.to_out.0")
        if "10.norm2" in k:
            k = k.replace("10.norm2", "10.1.net.0")
        if "10.mlp.fc1" in k:
            k = k.replace("10.mlp.fc1", "10.1.net.1")
        if "10.mlp.fc2" in k:
            k = k.replace("10.mlp.fc2", "10.1.net.4")

        if "11.norm1" in k:
            k = k.replace("11.norm1", "11.0.norm")
        if "11.attn.qkv" in k:
            k = k.replace("11.attn.qkv", "11.0.to_qkv")
        if "11.attn.proj" in k:
            k = k.replace("11.attn.proj", "11.0.to_out.0")
        if "11.norm2" in k:
            k = k.replace("11.norm2", "11.1.net.0")
        if "11.mlp.fc1" in k:
            k = k.replace("11.mlp.fc1", "11.1.net.1")
        if "11.mlp.fc2" in k:
            k = k.replace("11.mlp.fc2", "11.1.net.4")

        if "norm" in k and "transformer" not in k:
            k = k.replace("norm.weight", "transformer.norm.weight")
            k = k.replace("norm.bias", "transformer.norm.bias")
        
        if "head" in k:
            k = k.replace("head", "mlp_head")    
        
        newer_dict[k] = v
    
    return newer_dict