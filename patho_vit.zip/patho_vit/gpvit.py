import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

from einops import repeat, rearrange 
from einops.layers.torch import Rearrange

import torchvision.transforms as transforms

import matplotlib.pyplot as plt
from PIL import Image

from einops import repeat
from einops.layers.torch import Rearrange
from vit_pytorch import ViT
from vit_pytorch.vit import Transformer


def pair(t):
    return t if isinstance(t, tuple) else (t, t)

# classes

class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout = 0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)

class Attention(nn.Module):
    def __init__(self, dim, heads = 8, dim_head = 64, dropout = 0.):
        super().__init__()
        inner_dim = dim_head *  heads
        project_out = not (heads == 1 and dim_head == dim)

        self.heads = heads
        self.scale = dim_head ** -0.5

        self.norm = nn.LayerNorm(dim)

        self.attend = nn.Softmax(dim = -1)
        self.dropout = nn.Dropout(dropout)

        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias = False)

        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()

    def forward(self, x):
        x = self.norm(x)

        qkv = self.to_qkv(x).chunk(3, dim = -1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h = self.heads), qkv)

        dots = torch.matmul(q, k.transpose(-1, -2)) * self.scale

        attn = self.attend(dots)
        attn = self.dropout(attn)

        out = torch.matmul(attn, v)
        out = rearrange(out, 'b h n d -> b n (h d)')
        return self.to_out(out)

class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, dim_head, mlp_dim, dropout = 0.):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Attention(dim, heads = heads, dim_head = dim_head, dropout = dropout),
                FeedForward(dim, mlp_dim, dropout = dropout)
            ]))

    def forward(self, x):
        for attn, ff in self.layers:
            x = attn(x) + x
            x = ff(x) + x

        return self.norm(x)

class ViT(nn.Module):
    def __init__(self, *, image_size, patch_size, num_classes, dim, depth, heads, mlp_dim, pool = 'cls', channels = 3, dim_head = 64, dropout = 0., emb_dropout = 0.):
        super().__init__()
        image_height, image_width = pair(image_size)
        patch_height, patch_width = pair(patch_size)

        assert image_height % patch_height == 0 and image_width % patch_width == 0, 'Image dimensions must be divisible by the patch size.'

        num_patches = (image_height // patch_height) * (image_width // patch_width)
        patch_dim = channels * patch_height * patch_width
        assert pool in {'cls', 'mean'}, 'pool type must be either cls (cls token) or mean (mean pooling)'

        self.to_patch_embedding = nn.Sequential(
            Rearrange('b c (h p1) (w p2) -> b (h w) (c p1 p2)', p1 = patch_height, p2 = patch_width),
            nn.LayerNorm(patch_dim),
            nn.Linear(patch_dim, dim),
            nn.LayerNorm(dim),
        )

        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches + 1, dim))
        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        self.dropout = nn.Dropout(emb_dropout)

        self.transformer = Transformer(dim, depth, heads, dim_head, mlp_dim, dropout)

        self.pool = pool
        self.to_latent = nn.Identity()

        self.mlp_head = nn.Linear(dim, num_classes)

    def forward(self, img):
        x = self.to_patch_embedding(img)
        b, n, _ = x.shape

        cls_tokens = repeat(self.cls_token, '1 1 d -> b 1 d', b = b)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)

        x = self.transformer(x)

        x = x.mean(dim = 1) if self.pool == 'mean' else x[:, 0]

        x = self.to_latent(x)
        return self.mlp_head(x)

class MAE(nn.Module):
    def __init__(self, *, encoder, masking_ratio = 0.75,
                decoder_dim, decoder_depth = 8, decoder_heads = 8, decoder_dim_head = 64):
        super().__init__()
        assert masking_ratio > 0 and masking_ratio < 1
        self.masking_ratio = masking_ratio
        
        self.encoder = encoder
        num_patches, encoder_dim = encoder.pos_embedding.shape[-2:]
        
        self.to_patch = encoder.to_patch_embedding[0]
        self.patch_to_emb = nn.Sequential(*encoder.to_patch_embedding[1:])
        pixel_values_per_patch = encoder.to_patch_embedding[2].weight.shape[-1]
        
        self.decoder_dim = decoder_dim
        self.enc_to_dec = nn.Linear(encoder_dim, decoder_dim) if encoder_dim != decoder_dim else nn.Identity()
        self.decoder_pos_emb = nn.Embedding(num_patches, decoder_dim)
        self.black_token = nn.Parameter(torch.randn(decoder_dim))
        self.decoder = Transformer(dim = decoder_dim, depth = decoder_depth, heads = decoder_heads, dim_head = decoder_dim_head, mlp_dim = decoder_dim * 4)
        self.to_pixels = nn.Linear(decoder_dim, pixel_values_per_patch)
        
    def forward(self, img):
        device = img.device
        
        patches = self.to_patch(img)
        batch, num_patches, patch_dim = patches.shape
        tokens = self.patch_to_emb(patches)
        
        if self.encoder.pool == "cls":
            tokens += self.encoder.pos_embedding[:, 1:(num_patches + 1)]
        elif self.encoder.pool == "mean":
            tokens += self.encoder.pos_embedding.to(device, dtype = tokens.dtype)
        
        num_black = int(self.masking_ratio * num_patches)
        rand_indices = torch.rand(batch, num_patches, device = device).argsort(dim = -1)
        black_indices, white_indices = rand_indices[:, :num_black], rand_indices[:, num_black:]
        batch_range = torch.arange(batch, device = device)[:, None]
        white_tokens = tokens[batch_range, white_indices]
        
        white_tokens = self.encoder.transformer(white_tokens)
        
        white_tokens = self.enc_to_dec(white_tokens)
        white_tokens += self.decoder_pos_emb(white_indices)
        
        black_tokens = repeat(self.black_token, "d -> b n d", b = batch, n = num_black)
        black_tokens = black_tokens + self.decoder_pos_emb(black_indices)
        
        decoder_tokens = torch.zeros(batch, num_patches, self.decoder_dim, device = device)
        decoder_tokens[batch_range, white_indices] = white_tokens
        decoder_tokens[batch_range, black_indices] = black_tokens
        
        decoder_tokens = self.decoder(decoder_tokens)
        
        black_tokens = decoder_tokens[batch_range, black_indices]
        pred_pixel_values = self.to_pixels(black_tokens)
        
        black_patches = patches[batch_range, black_indices]
        recon_loss = F.mse_loss(pred_pixel_values, black_patches)
        return recon_loss


class Recon(nn.Module):
    def __init__(self, mae):
        super().__init__()
        self.mae = mae.module
        self.mae.eval()
        
    def forward(self, img):
        device = img.device
        
        rearrange = Rearrange(' b c (h p1) (w p2) -> b (h w) (p1 p2 c)', p1 = 16, p2 = 16)
        patches = rearrange(img)
        batch, num_patches, patch_dim = patches.shape
        tokens = self.mae.patch_to_emb(patches)
        
        if self.mae.encoder.pool == "cls":
            tokens += self.mae.encoder.pos_embedding[:, 1:(num_patches + 1)]
        elif self.mae.encoder.pool == "mean":
            tokens += self.mae.encoder.pos_embedding.to(device, dtype = tokens.dtype)
        
        num_black = int(0.75 * num_patches)
        rand_indices = torch.rand(batch, num_patches, device = device).argsort(dim = -1)
        black_indices, white_indices = rand_indices[:, :num_black], rand_indices[:, num_black:]
        batch_range = torch.arange(batch, device = device)[:, None]
        white_tokens = tokens[batch_range, white_indices]
        
        white_tokens = self.mae.encoder.transformer(white_tokens)
        output_tokens = white_tokens.clone()
        
        white_tokens = self.mae.enc_to_dec(white_tokens)
        white_tokens += self.mae.decoder_pos_emb(white_indices)
        
        black_tokens = repeat(self.mae.black_token, "d -> b n d", b = batch, n = num_black)
        black_tokens = black_tokens + self.mae.decoder_pos_emb(black_indices)
        
        decoder_tokens = torch.zeros(batch, num_patches, 512, device = device)
        decoder_tokens[batch_range, white_indices] = white_tokens
        decoder_tokens[batch_range, black_indices] = black_tokens
        
        decoder_tokens = self.mae.decoder(decoder_tokens)
        
        black_tokens = decoder_tokens[batch_range, black_indices]
        pred_pixel_values = self.mae.to_pixels(black_tokens)
        
        mosaic_patches = torch.zeros(batch, num_black, patch_dim, device = device)
        patches[batch_range, black_indices] = mosaic_patches
        
        rearrange2 = Rearrange('b (h w) (p1 p2 c) -> b c (h p1) (w p2)', h = 24, p1 = 16, p2 = 16)
        
        patches = rearrange2(patches)
        denorm = transforms.Normalize((-2.12, -2.04, -1.80), (4.37, 4.46, 4.44))
        patches = patches.clone().squeeze()
        patches = denorm(patches).clamp_(0, 1)
        #torchvision.utils.save_image(patches, 'patches.png')
        
        recon_image = self.mae.to_pixels(decoder_tokens)
        
        recon_image = rearrange2(recon_image)
        recon_image = recon_image.clone().squeeze()
        recon_image = denorm(recon_image).clamp_(0, 1)
        #torchvision.utils.save_image(recon_image, 'recon_img.png')
    
        return patches, recon_image, output_tokens

