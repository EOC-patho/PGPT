import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import cv2
from PIL import Image
from vit2.CLS2IDX import CLS2IDX
import torchvision.transforms as transforms

def print_top_classes(predictions, **kwargs):    
    # Print Top-5 predictions
    prob = torch.softmax(predictions, dim=1)
    # torch.softmax将原始预测值转换成百分比
    #class_indices = predictions.data.topk(5, dim=1)[1][0].tolist()
    class_indices = predictions.data.topk(2, dim=1)[1][0].tolist()
    # 输出值.data.topk返回两行数值，第一行为原始预测值，第二行为索引值，形状为（1，k），
    # 用[0]消去形状，用tolist变成列表
    max_str_len = 0
    class_names = []
    for cls_idx in class_indices:
        class_names.append(CLS2IDX[cls_idx])
        if len(CLS2IDX[cls_idx]) > max_str_len:
            max_str_len = len(CLS2IDX[cls_idx])
    
    print('Top 2 classes:')
    #print('Top 5 classes:')
    for cls_idx in class_indices:
        output_string = '\t{} : {}'.format(cls_idx, CLS2IDX[cls_idx])
        output_string += ' ' * (max_str_len - len(CLS2IDX[cls_idx])) + '\t\t'
        output_string += 'value = {:.3f}\t prob = {:.1f}%'.format(predictions[0, cls_idx], 100 * prob[0, cls_idx])
        print(output_string)


class CamModel: # 全名class activation mapping
    def __init__(self, model):
        self.model = model
        self.model.eval()

    def generate_cam(self, input, index= None):
        output = self.model(input, register_hook = True)
        
        if index == None:
            index = output.argmax(dim = -1)
        
        one_hot = torch.zeros((1, output.size()[-1]))
        one_hot[0][index] = 1
        one_hot = torch.sum(one_hot * output)
        
        self.model.zero_grad()
        one_hot.backward(retain_graph = True)

        #grad = self.model.blocks[-1].attn.get_attn_gradients()
        grad = self.model.transformer.layers[-1][0].get_attn_gradients()
        grad = grad[:, :, 0, 1:].reshape(1, -1, 24, 24)
        #grad = grad[:, :, 0, 1:].reshape(1, -1, 14, 14)
        
        cam = grad.mean(dim = 1, keepdim = True).clamp(min = 0)
        max11 = cam.max()
        scale_down = 255/max11
        cam = cam * scale_down

        #cam = (cam - cam.min()) / (cam.max() - cam.min())
        
        return cam

def generate_heatmap(model, image, transformed_image, index = None, img_size = 384, n = 3, num_verti_patches = 100, num_hori_patches = 100):   
    # n是你打算调出多少的热点，num_verti_patchesnum_patch_height纵向补丁总个数，num_hori_patchesnum_patch_width横向补丁总个数，img_size模型对应的输入图片尺寸，num_patches模型对应的横向（或纵向）的补丁数，
    # 本例中，为模型名称vit_base_patch16_224里224/16 = 14
    
    w, h = image.size
    image = np.array(image) / 255
    #image = image / 255

#   cam = model.generate_cam(transformed_image.unsqueeze(0).cuda(), index=index).detach()
    cam = model.generate_cam(transformed_image.unsqueeze(0), index=index)#.detach()
    cam = torch.nn.functional.interpolate(cam, scale_factor=16, mode='bilinear')
    cam = cam.reshape(img_size, img_size).cpu().numpy() #    cam = cam.reshape(224, 224).cuda().cpu().numpy()
    
    index = np.argsort(cam.ravel())[:-(n+1):-1] # 此处需要的最大值的个数加1，得到-3，后面的-1表示反向计算，不用更改
    pos = np.unravel_index(index, cam.shape)
    pos = np.column_stack(pos).astype(float)
    rel_pos = pos / img_size
    patch_index = (rel_pos[:, 0] * num_verti_patches, rel_pos[:, 1] * num_hori_patches)
    patch_index = np.column_stack(patch_index).astype(int)
    
    plt.imsave("cam.jpg", cam)
    cam = Image.open("cam.jpg")
    cam = cam.resize((w, h), Image.Resampling.LANCZOS)
    cam = np.array(cam)
    #cam = (cam - cam.min()) / (cam.max() - cam.min())

    heatmap = cv2.applyColorMap(cam, cv2.COLORMAP_JET)
    heatmap = heatmap / 255
    #heatmap = (heatmap - heatmap.min()) / (heatmap.max() - heatmap.min())
    
    heatmap += image
    heatmap = heatmap / np.max(heatmap)
    heatmap = np.uint8(255 * heatmap)  # 消融试验得知：此处必须为np.uin8格式
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_RGB2BGR)
    
    return heatmap, patch_index


def generate_heatmap_224(model, image, transformed_image, index = None, img_size = 224, n = 3, num_verti_patches = 80, num_hori_patches = 100):   
    # n是你打算调出多少的热点，num_verti_patchesnum_patch_height纵向补丁总个数，num_hori_patchesnum_patch_width横向补丁总个数，img_size模型对应的输入图片尺寸，num_patches模型对应的横向（或纵向）的补丁数，
    # 本例中，为模型名称vit_base_patch16_224里224/16 = 14
    transform = transforms.Resize([1024, 1024], interpolation = Image.NEAREST)
    image = transform(image)   
    w, h = image.size
    image = np.array(image) / 255
    #image = image / 255

#   cam = model.generate_cam(transformed_image.unsqueeze(0).cuda(), index=index).detach()
    cam = model.generate_cam(transformed_image.unsqueeze(0), index=index)#.detach()
    
    cam = torch.nn.functional.interpolate(cam, scale_factor=16, mode='bilinear')

    cam = cam.reshape(img_size, img_size).cpu().numpy() #    cam = cam.reshape(224, 224).cuda().cpu().numpy()
    
    index = np.argsort(cam.ravel())[:-(n+1):-1] # 此处需要的最大值的个数加1，得到-3，后面的-1表示反向计算，不用更改
    pos = np.unravel_index(index, cam.shape)
    pos = np.column_stack(pos).astype(float)
    rel_pos = pos / img_size
    patch_index = (rel_pos[:, 0] * num_verti_patches, rel_pos[:, 1] * num_hori_patches)
    patch_index = np.column_stack(patch_index).astype(int)
    
    plt.imsave("cam.jpg", cam)
    cam = Image.open("cam.jpg")
    cam = cam.resize((w, h), Image.Resampling.LANCZOS)
    cam = np.array(cam)
    #cam = (cam - cam.min()) / (cam.max() - cam.min())

    heatmap = cv2.applyColorMap(cam, cv2.COLORMAP_JET)
    heatmap = heatmap / 255
    #heatmap = (heatmap - heatmap.min()) / (heatmap.max() - heatmap.min())
    
    heatmap += image
    heatmap = heatmap / np.max(heatmap)
    heatmap = np.uint8(255 * heatmap)  # 消融试验得知：此处必须为np.uin8格式
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_RGB2BGR)
    
    return heatmap, patch_index


def generate_heatmap_any(model, image, transformed_image, index = None, img_size = 224, n = 3, num_verti_patches = 80, num_hori_patches = 100):   
    # n是你打算调出多少的热点，num_verti_patchesnum_patch_height纵向补丁总个数，num_hori_patchesnum_patch_width横向补丁总个数，img_size模型对应的输入图片尺寸，num_patches模型对应的横向（或纵向）的补丁数，
    # 本例中，为模型名称vit_base_patch16_224里224/16 = 14
    
    transform = transforms.Resize([1024, 1024], interpolation = Image.NEAREST)
    image = transform(image)
    w, h = image.size
    image = np.array(image) / 255
    #image = image / 255

#   cam = model.generate_cam(transformed_image.unsqueeze(0).cuda(), index=index).detach()
    cam = model.generate_cam(transformed_image.unsqueeze(0), index=index)#.detach()
    cam = torch.nn.functional.interpolate(cam, scale_factor=16, mode='bilinear')
    cam = cam.reshape(img_size, img_size).cpu().numpy() #    cam = cam.reshape(224, 224).cuda().cpu().numpy()
    
    index = np.argsort(cam.ravel())[:-(n+1):-1] # 此处需要的最大值的个数加1，得到-3，后面的-1表示反向计算，不用更改
    pos = np.unravel_index(index, cam.shape)
    pos = np.column_stack(pos).astype(float)
    rel_pos = pos / img_size
    patch_index = (rel_pos[:, 0] * num_verti_patches, rel_pos[:, 1] * num_hori_patches)
    patch_index = np.column_stack(patch_index).astype(int)
    
    plt.imsave("cam.jpg", cam)
    cam = Image.open("cam.jpg")
    cam = cam.resize((w, h), Image.Resampling.LANCZOS)
    cam = np.array(cam)
    #cam = (cam - cam.min()) / (cam.max() - cam.min())

    heatmap = cv2.applyColorMap(cam, cv2.COLORMAP_HSV)
    heatmap = heatmap / 255
    #heatmap = (heatmap - heatmap.min()) / (heatmap.max() - heatmap.min())
    
    heatmap += image
    heatmap = heatmap / np.max(heatmap)
    heatmap = np.uint8(255 * heatmap)  # 消融试验得知：此处必须为np.uin8格式
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_RGB2BGR)
    
    return heatmap, patch_index