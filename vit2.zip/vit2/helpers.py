import torch

def timm2luci(weight_path):
    if torch.cuda.is_available():
        old_dict = torch.load(weight_path)
    else:
        old_dict = torch.load(weight_path, map_location=torch.device('cpu'))
    
    new_dict = {}

    if "epoch" in list(old_dict.keys()):
        for k, v in list(old_dict["state_dict"].items()):
            name = k[11:] if k.startswith('module') else k # 此处的11删除了module.vit.
            new_dict[name] = v
    else:
        for k, v in list(old_dict.items()):
            
            name = k[7:] if k.startswith('module') else k
            new_dict[name] = v

    newer_dict = {}
    for k, v in list(new_dict.items()):
        if "embed" in k:
            k = k.replace("embed", "embedding")
        if "patch" in k:
            k = k.replace("patch", "to_patch")
        if "embedding.proj.weight" in k:
            k = k.replace("embedding.proj.weight", "embedding.2.weight")
            v = v.reshape(768, 768)
        if "embedding.proj.bias" in k:
            k = k.replace("embedding.proj.bias", "embedding.2.bias")
    
        if "blocks" in k:
            k = k.replace("blocks", "transformer.layers")
    
        if "0.norm1" in k:
            k = k.replace("0.norm1", "0.0.norm")
        if "0.attn.qkv" in k:
            k = k.replace("0.attn.qkv", "0.0.to_qkv")
        if "0.attn.proj" in k:
            k = k.replace("0.attn.proj", "0.0.to_out.0")
        if "0.norm2" in k:
            k = k.replace("0.norm2", "0.1.net.0")
        if "0.mlp.fc1" in k:
            k = k.replace("0.mlp.fc1", "0.1.net.1")
        if "0.mlp.fc2" in k:
            k = k.replace("0.mlp.fc2", "0.1.net.4")

        if "1.norm1" in k:
            k = k.replace("1.norm1", "1.0.norm")
        if "1.attn.qkv" in k:
            k = k.replace("1.attn.qkv", "1.0.to_qkv")
        if "1.attn.proj" in k:
            k = k.replace("1.attn.proj", "1.0.to_out.0")
        if "1.norm2" in k:
            k = k.replace("1.norm2", "1.1.net.0")
        if "1.mlp.fc1" in k:
            k = k.replace("1.mlp.fc1", "1.1.net.1")
        if "1.mlp.fc2" in k:
            k = k.replace("1.mlp.fc2", "1.1.net.4")

    
        if "2.norm1" in k:
            k = k.replace("2.norm1", "2.0.norm")
        if "2.attn.qkv" in k:
            k = k.replace("2.attn.qkv", "2.0.to_qkv")
        if "2.attn.proj" in k:
            k = k.replace("2.attn.proj", "2.0.to_out.0")
        if "2.norm2" in k:
            k = k.replace("2.norm2", "2.1.net.0")
        if "2.mlp.fc1" in k:
            k = k.replace("2.mlp.fc1", "2.1.net.1")
        if "2.mlp.fc2" in k:
            k = k.replace("2.mlp.fc2", "2.1.net.4")

        if "3.norm1" in k:
            k = k.replace("3.norm1", "3.0.norm")
        if "3.attn.qkv" in k:
            k = k.replace("3.attn.qkv", "3.0.to_qkv")
        if "3.attn.proj" in k:
            k = k.replace("3.attn.proj", "3.0.to_out.0")
        if "3.norm2" in k:
            k = k.replace("3.norm2", "3.1.net.0")
        if "3.mlp.fc1" in k:
            k = k.replace("3.mlp.fc1", "3.1.net.1")
        if "3.mlp.fc2" in k:
            k = k.replace("3.mlp.fc2", "3.1.net.4")

        if "4.norm1" in k:
            k = k.replace("4.norm1", "4.0.norm")
        if "4.attn.qkv" in k:
            k = k.replace("4.attn.qkv", "4.0.to_qkv")
        if "4.attn.proj" in k:
            k = k.replace("4.attn.proj", "4.0.to_out.0")
        if "4.norm2" in k:
            k = k.replace("4.norm2", "4.1.net.0")
        if "4.mlp.fc1" in k:
            k = k.replace("4.mlp.fc1", "4.1.net.1")
        if "4.mlp.fc2" in k:
            k = k.replace("4.mlp.fc2", "4.1.net.4")

        if "5.norm1" in k:
            k = k.replace("5.norm1", "5.0.norm")
        if "5.attn.qkv" in k:
            k = k.replace("5.attn.qkv", "5.0.to_qkv")
        if "5.attn.proj" in k:
            k = k.replace("5.attn.proj", "5.0.to_out.0")
        if "5.norm2" in k:
            k = k.replace("5.norm2", "5.1.net.0")
        if "5.mlp.fc1" in k:
            k = k.replace("5.mlp.fc1", "5.1.net.1")
        if "5.mlp.fc2" in k:
            k = k.replace("5.mlp.fc2", "5.1.net.4")
        
        if "6.norm1" in k:
            k = k.replace("6.norm1", "6.0.norm")
        if "6.attn.qkv" in k:
            k = k.replace("6.attn.qkv", "6.0.to_qkv")
        if "6.attn.proj" in k:
            k = k.replace("6.attn.proj", "6.0.to_out.0")
        if "6.norm2" in k:
            k = k.replace("6.norm2", "6.1.net.0")
        if "6.mlp.fc1" in k:
            k = k.replace("6.mlp.fc1", "6.1.net.1")
        if "6.mlp.fc2" in k:
            k = k.replace("6.mlp.fc2", "6.1.net.4")

        if "7.norm1" in k:
            k = k.replace("7.norm1", "7.0.norm")
        if "7.attn.qkv" in k:
            k = k.replace("7.attn.qkv", "7.0.to_qkv")
        if "7.attn.proj" in k:
            k = k.replace("7.attn.proj", "7.0.to_out.0")
        if "7.norm2" in k:
            k = k.replace("7.norm2", "7.1.net.0")
        if "7.mlp.fc1" in k:
            k = k.replace("7.mlp.fc1", "7.1.net.1")
        if "7.mlp.fc2" in k:
            k = k.replace("7.mlp.fc2", "7.1.net.4")

        if "8.norm1" in k:
            k = k.replace("8.norm1", "8.0.norm")
        if "8.attn.qkv" in k:
            k = k.replace("8.attn.qkv", "8.0.to_qkv")
        if "8.attn.proj" in k:
            k = k.replace("8.attn.proj", "8.0.to_out.0")
        if "8.norm2" in k:
            k = k.replace("8.norm2", "8.1.net.0")
        if "8.mlp.fc1" in k:
            k = k.replace("8.mlp.fc1", "8.1.net.1")
        if "8.mlp.fc2" in k:
            k = k.replace("8.mlp.fc2", "8.1.net.4")

        if "9.norm1" in k:
            k = k.replace("9.norm1", "9.0.norm")
        if "9.attn.qkv" in k:
            k = k.replace("9.attn.qkv", "9.0.to_qkv")
        if "9.attn.proj" in k:
            k = k.replace("9.attn.proj", "9.0.to_out.0")
        if "9.norm2" in k:
            k = k.replace("9.norm2", "9.1.net.0")
        if "9.mlp.fc1" in k:
            k = k.replace("9.mlp.fc1", "9.1.net.1")
        if "9.mlp.fc2" in k:
            k = k.replace("9.mlp.fc2", "9.1.net.4")

        if "10.norm1" in k:
            k = k.replace("10.norm1", "10.0.norm")
        if "10.attn.qkv" in k:
            k = k.replace("10.attn.qkv", "10.0.to_qkv")
        if "10.attn.proj" in k:
            k = k.replace("10.attn.proj", "10.0.to_out.0")
        if "10.norm2" in k:
            k = k.replace("10.norm2", "10.1.net.0")
        if "10.mlp.fc1" in k:
            k = k.replace("10.mlp.fc1", "10.1.net.1")
        if "10.mlp.fc2" in k:
            k = k.replace("10.mlp.fc2", "10.1.net.4")

        if "11.norm1" in k:
            k = k.replace("11.norm1", "11.0.norm")
        if "11.attn.qkv" in k:
            k = k.replace("11.attn.qkv", "11.0.to_qkv")
        if "11.attn.proj" in k:
            k = k.replace("11.attn.proj", "11.0.to_out.0")
        if "11.norm2" in k:
            k = k.replace("11.norm2", "11.1.net.0")
        if "11.mlp.fc1" in k:
            k = k.replace("11.mlp.fc1", "11.1.net.1")
        if "11.mlp.fc2" in k:
            k = k.replace("11.mlp.fc2", "11.1.net.4")

        if "norm" in k and "transformer" not in k:
            k = k.replace("norm.weight", "transformer.norm.weight")
            k = k.replace("norm.bias", "transformer.norm.bias")
        
        if "head" in k:
            k = k.replace("head", "mlp_head")    
        
        newer_dict[k] = v
    
    return newer_dict