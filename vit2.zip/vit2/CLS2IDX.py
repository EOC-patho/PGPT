CLS2IDX = {0: 'live',
 1: '3-y death',
 2: '5-y death'}